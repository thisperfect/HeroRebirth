EXEC_QUEUE_TYPE_CREATERES 		= 1
EXEC_QUEUE_TYPE_CREATEMONSTER 	= 2
EXEC_QUEUE_TYPE_CREATESHELTER	= 3

local totle_minute;
function IN_GetCondSql( cond, sql )
	
end

-- ϵͳ����ʱִ��
function IN_Script_Init()
	math.randomseed(os.time())
end

-- ϵͳÿ����ִ��һ��
function IN_Script_Timer()
	
end

-- ϵͳÿСʱִ��һ��
function IN_Script_Hour()
	map_monster_brush( 0 );
	MonsterGroupFightBrush( 0 );
end

-- ����ִ��
function IN_OnClockProcess( hour )
	if hour == 3 then
		-- ˢҰ��
		IN_OnWorldMapBrush();
	end
end

-- ϵͳʱ���ַ���
function IN_TimeString( timestamp )
	return os.date("%Y-%m-%d %X", timestamp), 0;
end

-- ϵͳGMָ��
function IN_Script_Command( v1, v2, v3, v4, msg, PlayerIdx )
	local temp = os.date("*t", os.time());
	
	-- Ұ��ˢ��
	if v1 == 1 then
		map_res_brush( 0 );
	elseif v1 == 2 then	
		map_monster_brush( 0 );
	elseif v1 == 3 then
		map_shelter_brush( 0 );
	elseif v1 == 4 then
		DragonGroupFightOpen();
	elseif v1 == 5 then
		DragonGroupFightBrush(1);
	elseif v1 == 6 then
		DragonGroupFightEnd();
	elseif v1 == 7 then
		MonsterGroupFightOpen();
	elseif v1 == 8 then
		MonsterGroupFightBrush( 1 );
	elseif v1 == 9 then
		MonsterGroupFightEnd();
	elseif v1 == 10 then
		MonsterGroupFightBrush( 0 );
	elseif v1 == 11 then
		ShowDenOpen();
	elseif v1 == 12 then
		ShowDenBrush( 1, 2000 );
	elseif v1 == 13 then
		ShowDenEnd();
	end
	return 0;
end

function IN_Script_Exec( id, value1, value2 )
	if id == EXEC_QUEUE_TYPE_CREATERES then
		map_res_brushsingle();
	elseif id == EXEC_QUEUE_TYPE_CREATEMONSTER then
		map_monster_brushsingle( value1, value2 );
	elseif id == EXEC_QUEUE_TYPE_CREATESHELTER then
		map_shelter_brushsingle();
	end
end

