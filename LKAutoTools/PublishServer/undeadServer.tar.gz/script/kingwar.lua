--ȫ�˷��ʼ�����ʱ��
local KingWarTime = { 8640, 4320, 60, 5, 1 }
function IN_OnKingWarMailTime( countdown )
	if countdown == 8640 then
		c_city_all_sendmail_withlevel( 15, 6076, 6155, "", "", "", 9);
		return countdown;
	end
	if countdown ==4320 then
		c_city_all_sendmail_withlevel( 15, 6077, 6156, "", "", "", 9);
		return countdown;
	end
	for i=1,5,1 do
		if KingWarTime[i] == countdown then
			if i > 2 then
				c_system_rollingparam( 8100, countdown, "", "", 1 );
				local x = string.format( "$#|99|%d|%d|%d|", 11996, 8100, countdown );
				c_system_talk( x, 100 );
			end
			return i;
		end
	end
	return 0;
end

--����ս���ֹ���
local KingWarPoint={ 100, 1000, 5000, 8000, 9500, 10000 }
function IN_OnKingWarPointMsg( point )
	for i=1,5,1 do
		if KingWarPoint[i] == point then
			return i;
		end
	end
	if KingWarPoint[6] == point then
		return -6;
	end
	return 0;
end