-- ���߲���
ITEM_ABILITY_SCRIPTID				=	25	-- �ű�����ID

------------------------------------------------------------------ ���ߵĽű���������� ------------------------------------------------------------------------
function IN_UseItem( PlayerIdx, nMember, nItemIndex, nItemKind, nUseNum )
	local nID = c_item_get_ability_value( nItemKind, ITEM_ABILITY_SCRIPTID );
	if nID == 1 then
		c_item_getitem( PlayerIdx, 101, 100, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 102, 100, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 103, 100, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 104, 100, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 105, 100, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 106, 100, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 107, 100, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 108, 100, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 109, 100, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 110, 100, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 113, 50, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 115, 50, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 118, 50, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 121, 50, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 124, 50, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 199, 50, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 201, 10, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 206, 50, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 208, 50, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 210, 50, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 214, 50, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 215, 50, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 216, 50, -1, PATH_GM );
		
	elseif nID == 2 then
		c_item_getitem( PlayerIdx, 128, 100, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 129, 100, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 138, 100, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 139, 100, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 148, 100, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 149, 100, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 158, 100, -1, PATH_GM );
		c_item_getitem( PlayerIdx, 159, 100, -1, PATH_GM );
		
	elseif nID == 3 then
	
	end
	return nUseNum;
end
