-- ����

-- ÿ�յ�½����
local LoginAwardList = { 
[0] = { kind=-301, num=1 },
[1] = { kind=-302, num=1 },
[2] = { kind=-303, num=1 },
[3] = { kind=-304, num=1 },
[4] = { kind=-305, num=1 },
[5] = { kind=-306, num=1 },
[6] = { kind=-307, num=1 },
}


function IN_OnLoginAwardGet( index, platid, channelid, serverid )
	if LoginAwardList[index] == nil then
		return 0, 0;
	end 
	return LoginAwardList[index]["kind"], LoginAwardList[index]["num"];
end

-- ÿ��ʱ������
local TimeAwardList = { 
[1] = { 
[0] = { duration = 181, kind = -2201, num = 1 },
[1] = { duration = 294, kind = -311, num = 0 },
[2] = { duration = 572, kind = -312, num = 1 },
[3] = { duration = 872, kind = -313, num = 0 },
[4] = { duration = 917, kind = -314, num = 1 },
[5] = { duration = 1684, kind = -315, num = 1 },
[6] = { duration = 1857, kind = -2202, num = 1 },
[7] = { duration = 3888, kind = -316, num = 0 },
[8] = { duration = 6829, kind = -317, num = 1 },
[9] = { duration = 9829, kind = -2203, num = 1 },
[10] = { duration = 12829, kind = -319, num = 1 },
[11] = { duration = 12829, kind = -2203, num = 1 },
[12] = { duration = 14829, kind = -319, num = 1 },
[13] = { duration = 16829, kind = -320, num = 1 },
[14] = { duration = 2161, kind = -320, num = 1 },
},
[2] = { 
[0] = { duration = 181, kind = -2204, num = 1 },
[1] = { duration = 294, kind = -311, num = 0 },
[2] = { duration = 572, kind = -312, num = 1 },
[3] = { duration = 872, kind = -313, num = 0 },
[4] = { duration = 917, kind = -314, num = 1 },
[5] = { duration = 1684, kind = -315, num = 1 },
[6] = { duration = 1857, kind = -2205, num = 1 },
[7] = { duration = 3888, kind = -316, num = 0 },
[8] = { duration = 6829, kind = -317, num = 1 },
[9] = { duration = 9829, kind = -2206, num = 1 },
[10] = { duration = 12829, kind = -319, num = 1 },
[11] = { duration = 12829, kind = -2206, num = 1 },
[12] = { duration = 14829, kind = -319, num = 1 },
[13] = { duration = 16829, kind = -320, num = 1 },
[14] = { duration = 2161, kind = -320, num = 1 },
},
[3] = { 
[0] = { duration = 181, kind = -2207, num = 1 },
[1] = { duration = 294, kind = -311, num = 0 },
[2] = { duration = 572, kind = -312, num = 1 },
[3] = { duration = 872, kind = -313, num = 0 },
[4] = { duration = 917, kind = -314, num = 1 },
[5] = { duration = 1684, kind = -315, num = 1 },
[6] = { duration = 1857, kind = -2208, num = 1 },
[7] = { duration = 3888, kind = -316, num = 0 },
[8] = { duration = 6829, kind = -317, num = 1 },
[9] = { duration = 9829, kind = -2209, num = 1 },
[10] = { duration = 12829, kind = -319, num = 1 },
[11] = { duration = 12829, kind = -2209, num = 1 },
[12] = { duration = 14829, kind = -319, num = 1 },
[13] = { duration = 16829, kind = -320, num = 1 },
[14] = { duration = 2161, kind = -320, num = 1 },
},
[4] = { 
[0] = { duration = 181, kind = -2210, num = 1 },
[1] = { duration = 294, kind = -311, num = 0 },
[2] = { duration = 572, kind = -312, num = 1 },
[3] = { duration = 872, kind = -313, num = 0 },
[4] = { duration = 917, kind = -314, num = 1 },
[5] = { duration = 1684, kind = -315, num = 1 },
[6] = { duration = 1857, kind = -2211, num = 1 },
[7] = { duration = 3888, kind = -316, num = 0 },
[8] = { duration = 6829, kind = -317, num = 1 },
[9] = { duration = 9829, kind = -2212, num = 1 },
[10] = { duration = 12829, kind = -319, num = 1 },
[11] = { duration = 12829, kind = -2212, num = 1 },
[12] = { duration = 14829, kind = -319, num = 1 },
[13] = { duration = 16829, kind = -320, num = 1 },
[14] = { duration = 2161, kind = -320, num = 1 },
},
[5] = { 
[0] = { duration = 181, kind = -2213, num = 1 },
[1] = { duration = 294, kind = -311, num = 0 },
[2] = { duration = 572, kind = -312, num = 1 },
[3] = { duration = 872, kind = -313, num = 0 },
[4] = { duration = 917, kind = -314, num = 1 },
[5] = { duration = 1684, kind = -315, num = 1 },
[6] = { duration = 1857, kind = -2214, num = 1 },
[7] = { duration = 3888, kind = -316, num = 0 },
[8] = { duration = 6829, kind = -317, num = 1 },
[9] = { duration = 9829, kind = -2215, num = 1 },
[10] = { duration = 12829, kind = -319, num = 1 },
[11] = { duration = 12829, kind = -2215, num = 1 },
[12] = { duration = 14829, kind = -319, num = 1 },
[13] = { duration = 16829, kind = -320, num = 1 },
[14] = { duration = 2161, kind = -320, num = 1 },
},
[6] = { 
[0] = { duration = 181, kind = -2216, num = 1 },
[1] = { duration = 294, kind = -311, num = 0 },
[2] = { duration = 572, kind = -312, num = 1 },
[3] = { duration = 872, kind = -313, num = 0 },
[4] = { duration = 917, kind = -314, num = 1 },
[5] = { duration = 1684, kind = -315, num = 1 },
[6] = { duration = 1857, kind = -2217, num = 1 },
[7] = { duration = 3888, kind = -316, num = 0 },
[8] = { duration = 6829, kind = -317, num = 1 },
[9] = { duration = 9829, kind = -2218, num = 1 },
[10] = { duration = 12829, kind = -319, num = 1 },
[11] = { duration = 12829, kind = -2218, num = 1 },
[12] = { duration = 14829, kind = -319, num = 1 },
[13] = { duration = 16829, kind = -320, num = 1 },
[14] = { duration = 2161, kind = -320, num = 1 },
},
[7] = { 
[0] = { duration = 181, kind = -2219, num = 1 },
[1] = { duration = 294, kind = -311, num = 0 },
[2] = { duration = 572, kind = -312, num = 1 },
[3] = { duration = 872, kind = -313, num = 0 },
[4] = { duration = 917, kind = -314, num = 1 },
[5] = { duration = 1684, kind = -315, num = 1 },
[6] = { duration = 1857, kind = -2220, num = 1 },
[7] = { duration = 3888, kind = -316, num = 0 },
[8] = { duration = 6829, kind = -317, num = 1 },
[9] = { duration = 9829, kind = -2221, num = 1 },
[10] = { duration = 12829, kind = -319, num = 1 },
[11] = { duration = 12829, kind = -2221, num = 1 },
[12] = { duration = 14829, kind = -319, num = 1 },
[13] = { duration = 16829, kind = -320, num = 1 },
[14] = { duration = 2161, kind = -320, num = 1 },
},
[8] = { 
[0] = { duration = 181, kind = -2222, num = 1 },
[1] = { duration = 294, kind = -311, num = 0 },
[2] = { duration = 572, kind = -312, num = 1 },
[3] = { duration = 872, kind = -313, num = 0 },
[4] = { duration = 917, kind = -314, num = 1 },
[5] = { duration = 1684, kind = -315, num = 1 },
[6] = { duration = 1857, kind = -2223, num = 1 },
[7] = { duration = 3888, kind = -316, num = 0 },
[8] = { duration = 6829, kind = -317, num = 1 },
[9] = { duration = 9829, kind = -2224, num = 1 },
[10] = { duration = 12829, kind = -319, num = 1 },
[11] = { duration = 12829, kind = -2224, num = 1 },
[12] = { duration = 14829, kind = -319, num = 1 },
[13] = { duration = 16829, kind = -320, num = 1 },
[14] = { duration = 2161, kind = -320, num = 1 },
},
[9] = { 
[0] = { duration = 181, kind = -2225, num = 1 },
[1] = { duration = 294, kind = -311, num = 0 },
[2] = { duration = 572, kind = -312, num = 1 },
[3] = { duration = 872, kind = -313, num = 0 },
[4] = { duration = 917, kind = -314, num = 1 },
[5] = { duration = 1684, kind = -315, num = 1 },
[6] = { duration = 1857, kind = -2226, num = 1 },
[7] = { duration = 3888, kind = -316, num = 0 },
[8] = { duration = 6829, kind = -317, num = 1 },
[9] = { duration = 9829, kind = -2227, num = 1 },
[10] = { duration = 12829, kind = -319, num = 1 },
[11] = { duration = 12829, kind = -2227, num = 1 },
[12] = { duration = 14829, kind = -319, num = 1 },
[13] = { duration = 16829, kind = -320, num = 1 },
[14] = { duration = 2161, kind = -320, num = 1 },
},
[10] = { 
[0] = { duration = 181, kind = -2228, num = 1 },
[1] = { duration = 294, kind = -311, num = 0 },
[2] = { duration = 572, kind = -312, num = 1 },
[3] = { duration = 872, kind = -313, num = 0 },
[4] = { duration = 917, kind = -314, num = 1 },
[5] = { duration = 1684, kind = -315, num = 1 },
[6] = { duration = 1857, kind = -2229, num = 1 },
[7] = { duration = 3888, kind = -316, num = 0 },
[8] = { duration = 6829, kind = -317, num = 1 },
[9] = { duration = 9829, kind = -2230, num = 1 },
[10] = { duration = 12829, kind = -319, num = 1 },
[11] = { duration = 12829, kind = -2230, num = 1 },
[12] = { duration = 14829, kind = -319, num = 1 },
[13] = { duration = 16829, kind = -320, num = 1 },
[14] = { duration = 2161, kind = -320, num = 1 },
},
}

function IN_OnTimeAwardGet( index, platid, channelid, serverid, onlineaward )
	if onlineaward == 0 then
		onlineaward = 1;
	end
	if TimeAwardList[onlineaward] == nil then
		return 0, 0, 0;
	end
	if TimeAwardList[onlineaward][index] == nil then
		return 0, 0, 0;
	end 
	return TimeAwardList[onlineaward][index]["duration"], TimeAwardList[onlineaward][index]["kind"], TimeAwardList[onlineaward][index]["num"];
end


-- ��Ծ�Ƚ���
local LivenessAwardList = { 
[1] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[2] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[3] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[4] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[5] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[6] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[7] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[8] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[9] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[10] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[11] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[12] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[13] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[14] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[15] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[16] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[17] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[18] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[19] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[20] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[21] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[22] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[23] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[24] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[25] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[26] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[27] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[28] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[29] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[30] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[31] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[32] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[34] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[34] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[35] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[36] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[37] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[38] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[39] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[40] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[41] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[42] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[43] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[44] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[45] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[46] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[47] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[48] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[49] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[50] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[51] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[52] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[53] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[54] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[55] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[56] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[57] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[58] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[59] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[60] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[61] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[62] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[63] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[64] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[65] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[66] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[67] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[68] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[69] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[70] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[71] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[72] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[73] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[74] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[75] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[76] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[77] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[78] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[79] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[80] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[81] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[82] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[83] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[84] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[85] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[86] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[87] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[88] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[89] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[90] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[91] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[82] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[93] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[94] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[95] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[96] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[97] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[98] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[99] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
[100] = { 340, 341, 342, 343, 344, 345, 346, 347, 348, 349 },
}

function IN_OnLivenessAwardGet( level, index, platid, channelid, serverid )
	if LivenessAwardList[level] == nil then
		return 0;
	end 
	if index > #LivenessAwardList[level] then
		index = 1;
	end
	return LivenessAwardList[level][index+1];
end


-- �ʵ�����
local Egg_Award = {
    [1] = {
     { kind = 256, num = 1 },
     { kind = 257, num = 1 },
     { kind = 258, num = 1 },
     { kind = 259, num = 1 },
     { kind = 240, num = 1 },
     { kind = 241, num = 1 },
     { kind = 242, num = 1 },
     { kind = 229, num = 1 },
     { kind = 191, num = 1 },
     { kind = 128, num = 1 },
     { kind = 138, num = 1 },
     { kind = 256, num = 1 },
     { kind = 257, num = 1 },
     { kind = 258, num = 1 },
     { kind = 259, num = 1 },
     { kind = 240, num = 1 },
     { kind = 241, num = 1 },
     { kind = 242, num = 1 },
     { kind = 229, num = 1 },
     { kind = 191, num = 1 },
     { kind = 128, num = 1 },
     { kind = 138, num = 1 },
     { kind = 228, num = 1 },
     { kind = 290, num = 1 },
     { kind = 103, num = 1 },
     { kind = 219, num = 1 },
     { kind = 222, num = 1 },
     { kind = 225, num = 1 },
     { kind = 299, num = 1 },
     { kind = 300, num = 1 },
     { kind = 301, num = 1 },
     { kind = 302, num = 1 },
    }
}

function IN_OnEggGet( index )
    if Egg_Award[index] == nil or #Egg_Award[index] == 0 then
        return 0, 0;
    end

    local award = Egg_Award[index][ math.random( 1, #Egg_Award[index] ) ];
    return award.kind, award.num;
end

-- �׶γ�ֵ����
local StageAwardList = {
[0]={0,1431,0,1432,0,1433},
[1]={0,1441,0,1442,0,1443},
[2]={0,1451,0,1452,0,1453},
} 
function IN_OnStageAwardGet( type, stage, platid, channelid, serverid )
	if StageAwardList[type] == nil then
		return 0
	end
	return StageAwardList[type][stage]
end

-- ������սÿ���ռ�����
local SevenDayAward={1750,1751,1752,1753,1754,1755,1756}
function IN_OnSevenDayAwardGet( day )
	if SevenDayAward[day] == nil then
		return 0
	end
	return SevenDayAward[day]
end

-- ���˳��ڽ׶ν���
local ClubAttendanceAward={ 2301, 2302, 2303 }
function IN_OnClubAttendanceAwardGet(num)
	if ClubAttendanceAward[num] == nil then
		return 0
	end
	return ClubAttendanceAward[num]
end

-- ����սǰ�˽���
local KingWarAward = { 471, 472, 473, 474, 475, 476, 477, 478 }
function IN_OnKingWarAwardGet( num )
	if KingWarAward[num] == nil then
		return 0;
	end
	return KingWarAward[num]
end

-- �ҵ���ҵ�����
local YokaAward={ 2617, 2616, 2615 }
function IN_OnYokaAwardGet(num)
	if YokaAward[num]==nil then
		return 0
	end
	return YokaAward[num]
end

-- �ҵ����������
local YokaRankAward={ 2618,2619,2620 }
function IN_OnYokaRankAwardGet(num)
	if YokaRankAward[num]==nil then
		return 0
	end
	return YokaRankAward[num]
end
