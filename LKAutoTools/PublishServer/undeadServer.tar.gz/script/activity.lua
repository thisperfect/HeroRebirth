
ACTIVITY_DRAGON_GROUPFIGHT	=	1 -- ����֮��
ACTIVITY_DRAGON_ATTACK		=	2 -- ����֮ŭ
ACTIVITY_MONSTER_GROUPFIGHT	=	3 -- ����Ұ��
ACTIVITY_LIMITTIME_SYSTEM	=	4 -- ��ʱ�
ACTIVITY_SNOWDEN			=	7 -- ѩ�˳�Ѩ

-- �����
function IN_ActivityOnOpen( activityid )
	if activityid == ACTIVITY_DRAGON_GROUPFIGHT then
		DragonGroupFightOpen()
	elseif activityid == ACTIVITY_DRAGON_ATTACK then
	elseif activityid == ACTIVITY_LIMITTIME_SYSTEM then
	elseif activityid == ACTIVITY_SNOWDEN then
		ShowDenOpen()
	end
end

-- �����
function IN_ActivityOnEnd( activityid )
	if activityid == ACTIVITY_DRAGON_GROUPFIGHT then
		DragonGroupFightEnd()
	elseif activityid == ACTIVITY_DRAGON_ATTACK then
	elseif activityid == ACTIVITY_LIMITTIME_SYSTEM then
	elseif activityid == ACTIVITY_SNOWDEN then
		ShowDenEnd()
	end
end

-- ��ر�
function IN_ActivityOnClose( activityid )
	if activityid == ACTIVITY_DRAGON_GROUPFIGHT then
		DragonGroupFightClose()
	elseif activityid == ACTIVITY_DRAGON_ATTACK then
	elseif activityid == ACTIVITY_LIMITTIME_SYSTEM then
	elseif activityid == ACTIVITY_SNOWDEN then
		ShowDenClose()
	end
end

-- �ÿ�����߼�
function IN_ActivityOnLogic( activityid )
	if activityid == ACTIVITY_DRAGON_GROUPFIGHT then
		DragonGroupFightLogic()
	elseif activityid == ACTIVITY_DRAGON_ATTACK then
	elseif activityid == ACTIVITY_LIMITTIME_SYSTEM then
	elseif activityid == ACTIVITY_SNOWDEN then
		ShowDenLogic()
	end
end

---------------------------------------- ����֮�� ----------------------------------------------
-- ����֮�ջ
function DragonGroupFightOpen()
	c_system_rollingmsg( 1, 0, "15000" );
	DragonGroupFightBrush( 0 );
end

function DragonGroupFightEnd()
	c_system_rollingmsg( 1, 0, "15002" );
	-- ɾ������֮�ջ�Ĺ�
	for index = 0, g_map_activity_maxcount-1, 1 do
		local id, action, _,_,_, hp = c_map_activityinfo( index );
		local _, _, _, _, _, _, _, _, _, activityid = c_map_activityconfig( id );
		if id > 0 and action == 0 and activityid == ACTIVITY_DRAGON_GROUPFIGHT then
			c_map_activity_delete( index );
		end
	end
end

function DragonGroupFightClose()
	
end

function DragonGroupFightLogic()
	
end

-- ��������ֵ��ȡ���й���ID
function DragonGroupFightGetID()
	-- ������������
	local runday = math.floor(c_system_getruntime()/86400);
	if runday <= 0 then
		runday = 1;
	end
	
	-- ˢ�ּ���	
	local DragonList = { {id=1,odds=85}, {id=2,odds=15}, {id=3,odds=0}, {id=4,odds=0} };		
	if runday >= 1 and runday <= 17 then		
		DragonList = { {id=1,odds=85}, {id=2,odds=15}, {id=3,odds=0}, {id=4,odds=0} };	
	elseif runday >= 18 and runday <= 52 then		
		DragonList = { {id=1,odds=60}, {id=2,odds=25}, {id=3,odds=5}, {id=4,odds=0} };	
	elseif runday >= 53 and runday <= 100 then		
		DragonList = { {id=1,odds=30}, {id=2,odds=50}, {id=3,odds=15}, {id=4,odds=5} };	
	elseif runday >= 101 and runday <= 180 then		
		DragonList = { {id=1,odds=20}, {id=2,odds=40}, {id=3,odds=25}, {id=4,odds=15} };	
	elseif runday >= 181 and runday <= 300 then		
		DragonList = { {id=1,odds=10}, {id=2,odds=30}, {id=3,odds=45}, {id=4,odds=15} };	
	elseif runday > 300 then		
		DragonList = { {id=1,odds=5}, {id=2,odds=25}, {id=3,odds=50}, {id=4,odds=20} };	
	end
	
	local count = #DragonList;
	local totlevalue = 0;	
	for tmpi=1,count,1 do
		totlevalue = totlevalue + DragonList[tmpi].odds;
	end
	if totlevalue <= 0 then	
		return 1;
	end
	local randvalue = math.random( 1, totlevalue );
	for tmpi=1, count, 1 do
		if randvalue <= DragonList[tmpi].odds then
			return DragonList[tmpi].id;
		end
		randvalue = randvalue - DragonList[tmpi].odds;
	end
	return 1;
end

-- ˢ��
function DragonGroupFightBrush( clear )
	
	-- ���
	if clear == 1 then
		for index = 0, g_map_activity_maxcount-1, 1 do
			local id, action, _,_,_, hp = c_map_activityinfo( index );
			local _, _, _, _, _, _, value1, value2, body, activityid = c_map_activityconfig( id );
			if id > 0 and action == 0 and activityid == ACTIVITY_DRAGON_GROUPFIGHT and hp == value1 then
				c_map_activity_delete( index );
			end
		end
		
		c_system_rollingmsg( 1, 0, "15001" );
	end
	
	-- ��ÿ����ѨΪ����ԭ�㣬��7*7�ķ�Χ�ڵĿհ׵ص�����
	for index = 0, g_map_shelter_maxcount-1, 1 do
		local posx, posy, deltime = c_map_shelterinfo( index );
		if deltime > 0 and os.time() < deltime then
			-- һ����Ѩˢ3��
			for tmpi = 1, 3, 1 do
				c_map_activity_area_brush( DragonGroupFightGetID(), posx, posy, 7 );
			end
			
		end
	end
	
end

---------------------------------------- ����֮ŭ ----------------------------------------------
-- ��ȡ����
local DragonArmyInfo = {
[-1] = { enemyid=300 },
[0] = { enemyid=300 },
[1] = { enemyid=301 },
[2] = { enemyid=302 },
[3] = { enemyid=306 },
[4] = { enemyid=308 },
[5] = { enemyid=1003 },
[6] = { enemyid=310 },
[7] = { enemyid=313 },
[8] = { enemyid=316 },
[9] = { enemyid=319 },
[10] = { enemyid=322 },
[11] = { enemyid=325 },
[12] = { enemyid=1013 },
[13] = { enemyid=328 },
[14] = { enemyid=331 },
[15] = { enemyid=334 },
[16] = { enemyid=337 },
[17] = { enemyid=340 },
[18] = { enemyid=343 },
[19] = { enemyid=1020 },
[20] = { enemyid=345 },
[21] = { enemyid=348 },
[22] = { enemyid=351 },
[23] = { enemyid=354 },
[24] = { enemyid=1820 },
[25] = { enemyid=358 },
[26] = { enemyid=362 },
[27] = { enemyid=366 },
[28] = { enemyid=1040 },
[29] = { enemyid=1835 },
[30] = { enemyid=1840 },
[31] = { enemyid=323 },
[32] = { enemyid=328 },
[33] = { enemyid=331 },
[34] = { enemyid=334 },
[35] = { enemyid=1031 },
[36] = { enemyid=340 },
[37] = { enemyid=343 },
[38] = { enemyid=346 },
[39] = { enemyid=349 },
[40] = { enemyid=352 },
[41] = { enemyid=355 },
[42] = { enemyid=1046 },
[43] = { enemyid=360 },
[44] = { enemyid=364 },
[45] = { enemyid=368 },
[46] = { enemyid=372 },
[47] = { enemyid=376 },
[48] = { enemyid=380 },
[49] = { enemyid=1071 },
[50] = { enemyid=384 },
[51] = { enemyid=388 },
[52] = { enemyid=392 },
[53] = { enemyid=396 },
[54] = { enemyid=1855 },
[55] = { enemyid=400 },
[56] = { enemyid=404 },
[57] = { enemyid=408 },
[58] = { enemyid=1098 },
[59] = { enemyid=1880 },
[60] = { enemyid=1899 },
[61] = { enemyid=360 },
[62] = { enemyid=364 },
[63] = { enemyid=368 },
[64] = { enemyid=372 },
[65] = { enemyid=1044 },
[66] = { enemyid=377 },
[67] = { enemyid=382 },
[68] = { enemyid=387 },
[69] = { enemyid=392 },
[70] = { enemyid=397 },
[71] = { enemyid=402 },
[72] = { enemyid=1077 },
[73] = { enemyid=405 },
[74] = { enemyid=410 },
[75] = { enemyid=415 },
[76] = { enemyid=420 },
[77] = { enemyid=425 },
[78] = { enemyid=430 },
[79] = { enemyid=1111 },
[80] = { enemyid=435 },
[81] = { enemyid=440 },
[82] = { enemyid=445 },
[83] = { enemyid=450 },
[84] = { enemyid=1888 },
[85] = { enemyid=460 },
[86] = { enemyid=465 },
[87] = { enemyid=470 },
[88] = { enemyid=1155 },
[89] = { enemyid=1921 },
[90] = { enemyid=1949 },
[91] = { enemyid=404 },
[92] = { enemyid=408 },
[93] = { enemyid=412 },
[94] = { enemyid=416 },
[95] = { enemyid=1080 },
[96] = { enemyid=420 },
[97] = { enemyid=425 },
[98] = { enemyid=430 },
[99] = { enemyid=435 },
[100] = { enemyid=440 },
[101] = { enemyid=445 },
[102] = { enemyid=1111 },
[103] = { enemyid=450 },
[104] = { enemyid=455 },
[105] = { enemyid=460 },
[106] = { enemyid=465 },
[107] = { enemyid=470 },
[108] = { enemyid=475 },
[109] = { enemyid=1133 },
[110] = { enemyid=481 },
[111] = { enemyid=487 },
[112] = { enemyid=493 },
[113] = { enemyid=499 },
[114] = { enemyid=1919 },
[115] = { enemyid=506 },
[116] = { enemyid=512 },
[117] = { enemyid=520 },
[118] = { enemyid=1216 },
[119] = { enemyid=1958 },
[120] = { enemyid=2016 },
[121] = { enemyid=433 },
[122] = { enemyid=439 },
[123] = { enemyid=445 },
[124] = { enemyid=451 },
[125] = { enemyid=1111 },
[126] = { enemyid=463 },
[127] = { enemyid=469 },
[128] = { enemyid=475 },
[129] = { enemyid=481 },
[130] = { enemyid=487 },
[131] = { enemyid=493 },
[132] = { enemyid=1166 },
[133] = { enemyid=500 },
[134] = { enemyid=507 },
[135] = { enemyid=514 },
[136] = { enemyid=521 },
[137] = { enemyid=528 },
[138] = { enemyid=535 },
[139] = { enemyid=1200 },
[140] = { enemyid=549 },
[141] = { enemyid=556 },
[142] = { enemyid=563 },
[143] = { enemyid=570 },
[144] = { enemyid=2012 },
[145] = { enemyid=580 },
[146] = { enemyid=590 },
[147] = { enemyid=600 },
[148] = { enemyid=1289 },
[149] = { enemyid=2016 },
[150] = { enemyid=2084 },
[151] = { enemyid=491 },
[152] = { enemyid=500 },
[153] = { enemyid=509 },
[154] = { enemyid=518 },
[155] = { enemyid=1155 },
[156] = { enemyid=536 },
[157] = { enemyid=545 },
[158] = { enemyid=554 },
[159] = { enemyid=563 },
[160] = { enemyid=572 },
[161] = { enemyid=581 },
[162] = { enemyid=1234 },
[163] = { enemyid=590 },
[164] = { enemyid=597 },
[165] = { enemyid=604 },
[166] = { enemyid=611 },
[167] = { enemyid=618 },
[168] = { enemyid=625 },
[169] = { enemyid=1263 },
[170] = { enemyid=632 },
[171] = { enemyid=640 },
[172] = { enemyid=648 },
[173] = { enemyid=656 },
[174] = { enemyid=2046 },
[175] = { enemyid=666 },
[176] = { enemyid=672 },
[177] = { enemyid=678 },
[178] = { enemyid=1372 },
[179] = { enemyid=2088 },
[180] = { enemyid=2172 },
[181] = { enemyid=520 },
[182] = { enemyid=530 },
[183] = { enemyid=540 },
[184] = { enemyid=550 },
[185] = { enemyid=1223 },
[186] = { enemyid=570 },
[187] = { enemyid=580 },
[188] = { enemyid=590 },
[189] = { enemyid=600 },
[190] = { enemyid=610 },
[191] = { enemyid=620 },
[192] = { enemyid=1245 },
[193] = { enemyid=630 },
[194] = { enemyid=640 },
[195] = { enemyid=650 },
[196] = { enemyid=660 },
[197] = { enemyid=670 },
[198] = { enemyid=680 },
[199] = { enemyid=1290 },
[200] = { enemyid=690 },
[201] = { enemyid=700 },
[202] = { enemyid=710 },
[203] = { enemyid=720 },
[204] = { enemyid=2112 },
[205] = { enemyid=735 },
[206] = { enemyid=750 },
[207] = { enemyid=767 },
[208] = { enemyid=1450 },
[209] = { enemyid=2170 },
[210] = { enemyid=2267 },
[211] = { enemyid=2267 },
[212] = { enemyid=2267 },
}

function IN_DragonArmyGetEnemy( state )	
	local beginlevel = DragonArmyGetBeginLevel();
	local level = beginlevel + state;
	if DragonArmyInfo[level] == nil then
		return 1;
	end
	return DragonArmyInfo[level].enemyid;
end
function IN_DragonArmyGetLevel( state )	
	local beginlevel = DragonArmyGetBeginLevel();
	local level = beginlevel + state;
	return level;
end
function DragonArmyGetBeginLevel()
	local beginlevel = 1;
	-- ������������
	local runday = math.floor(c_system_getruntime()/86400);
	if runday <= 0 then
		runday = 1;
	end
	
	if runday >= 1 and runday <= 4 then			
		beginlevel = 1;	
	elseif runday >= 5 and runday <= 17 then		
		beginlevel = 31;	
	elseif runday >= 18 and runday <= 52 then		
		beginlevel = 61;	
	elseif runday >= 53 and runday <= 100 then		
		beginlevel = 91;	
	elseif runday >= 101 and runday <= 180 then		
		beginlevel = 121;	
	elseif runday >= 181 and runday <= 300 then		
		beginlevel = 151;	
	else		
		beginlevel = 181;	
	end		
	
	return beginlevel;
end

-- ����֮ŭ��������а���
local DragonClubRankAward = {
[1] = 561,
[2] = 562,
[3] = 563,
[4] = 564,
[5] = 565,
[6] = 566,
[7] = 567,
[8] = 568,
[9] = 569,
[10] = 570,
}
-- ����֮ŭ��������а���
local DragonActorRankAward = {
[1] = 551,
[2] = 552,
[3] = 553,
[4] = 554,
[5] = 555,
[6] = 556,
[7] = 557,
[8] = 558,
[9] = 559,
[10] = 560,
}
function IN_DragonRankAward( rank, type )
	if rank <= 0 or rank > 10 then
		return -1;
	end
	if type == 0 then
		return DragonClubRankAward[rank];
	elseif type == 1 then 
		return DragonActorRankAward[rank];
	end
end

-- ���ֽ���
local DragonPointAward = {
{ actorpoint = 10000, clubpoint = 300000, awardgroup=571 },
{ actorpoint = 20000, clubpoint = 700000, awardgroup=572 },
{ actorpoint = 30000, clubpoint = 1100000, awardgroup=573 },
{ actorpoint = 40000, clubpoint = 1500000, awardgroup=574 },
{ actorpoint = 50000, clubpoint = 1900000, awardgroup=575 },
{ actorpoint = 60000, clubpoint = 2300000, awardgroup=576 },
{ actorpoint = 70000, clubpoint = 2700000, awardgroup=577 },
{ actorpoint = 80000, clubpoint = 3000000, awardgroup=578 },
{ actorpoint = 90000, clubpoint = 3300000, awardgroup=579 },
{ actorpoint = 100000, clubpoint = 3600000, awardgroup=580 },
{ actorpoint = 110000, clubpoint = 3900000, awardgroup=581 },
{ actorpoint = 120000, clubpoint = 4200000, awardgroup=582 },
{ actorpoint = 130000, clubpoint = 4500000, awardgroup=583 },
{ actorpoint = 140000, clubpoint = 4800000, awardgroup=584 },
{ actorpoint = 150000, clubpoint = 5100000, awardgroup=585 },
{ actorpoint = 160000, clubpoint = 5400000, awardgroup=586 },
{ actorpoint = 170000, clubpoint = 5700000, awardgroup=587 },
{ actorpoint = 180000, clubpoint = 6000000, awardgroup=588 },
{ actorpoint = 190000, clubpoint = 6300000, awardgroup=589 },
{ actorpoint = 200000, clubpoint = 6600000, awardgroup=590 },
{ actorpoint = 210000, clubpoint = 6900000, awardgroup=591 },
{ actorpoint = 220000, clubpoint = 7200000, awardgroup=592 },
{ actorpoint = 230000, clubpoint = 7500000, awardgroup=593 },
{ actorpoint = 240000, clubpoint = 7800000, awardgroup=594 },
{ actorpoint = 250000, clubpoint = 8100000, awardgroup=595 },
{ actorpoint = 260000, clubpoint = 8400000, awardgroup=596 },
{ actorpoint = 270000, clubpoint = 8700000, awardgroup=597 },
{ actorpoint = 280000, clubpoint = 9000000, awardgroup=598 },
{ actorpoint = 290000, clubpoint = 9300000, awardgroup=599 },
{ actorpoint = 300000, clubpoint = 9600000, awardgroup=600 },
}

function IN_DragonPointAward( actorpoint, clubpoint )
	local awardgroup = -1;
	for tmpi = #DragonPointAward, 1, -1 do
		if actorpoint >= DragonPointAward[tmpi].actorpoint and clubpoint >= DragonPointAward[tmpi].clubpoint then
			return DragonPointAward[tmpi].awardgroup, tmpi;
		end
	end
	return awardgroup, 0
end
function IN_DragonPointAwardList( level )
	if level <= 0 or level > #DragonPointAward then
		return -1, -1, -1;
	end
	return DragonPointAward[level].actorpoint, DragonPointAward[level].clubpoint, DragonPointAward[level].awardgroup;
end



---------------------------------------- ����Ұ�� ----------------------------------------------
function MonsterGroupFightOpen()
	MonsterGroupFightBrush( 1 );
end

function MonsterGroupFightEnd()
		
end

function MonsterGroupFightClose()
		
end

function MonsterGroupFightLogic()
	
end

-- ˢ��ÿ��
function MonsterGroupFightBrush( delete )
	--print( "map_monstergroupfight_brush" )
	
	local brushnumLevel1 = 5500;
	local brushnum = 3500;
	-- ɾ������Ұ��
	if delete == 1 then
		for index = 0, g_map_activity_maxcount-1, 1 do
			local id, action, _,_,_, hp = c_map_activityinfo( index );
			local _, _, _, _, _, _, _, _, _, activityid = c_map_activityconfig( id );
			if id > 0 and action == 0 and activityid == ACTIVITY_MONSTER_GROUPFIGHT then
				c_map_activity_delete( index );
			end
		end
		
	else
		
		-- ����
		brushnumLevel1 = 5500 - c_map_activity_getnum_withcondition( 10, ACTIVITY_MONSTER_GROUPFIGHT );
		brushnum = 3500 - ( c_map_activity_getnum_withcondition( 11, ACTIVITY_MONSTER_GROUPFIGHT ) + 
							c_map_activity_getnum_withcondition( 12, ACTIVITY_MONSTER_GROUPFIGHT ) + 
							c_map_activity_getnum_withcondition( 13, ACTIVITY_MONSTER_GROUPFIGHT ) + 
							c_map_activity_getnum_withcondition( 14, ACTIVITY_MONSTER_GROUPFIGHT ) );
	end
		
	-- ��ˢ1��
	while brushnumLevel1 > 0 do

		-- ���һ���հ׵�
		local posx, posy = c_map_getrandpos( -2 );
		local circleID = getCircleID( posx, posy );
		if circleID >= 2 and circleID <= 5 then
			c_map_activity_create( 10, posx, posy );
			brushnumLevel1 = brushnumLevel1 -1;
		end
		
	end
	
	-- ��ˢ
	while brushnum > 0 do

		-- ���һ���հ׵�
		local posx, posy = c_map_getrandpos( -2 );
		local circleID = getCircleID( posx, posy );
		if circleID >= 2 and circleID <= 5 then
			c_map_activity_create( math.random( 11, 14 ), posx, posy );
			brushnum = brushnum -1;
		end
		
	end
end



---------------------------------------- ѭ���� ----------------------------------------------

-- �ӻ��ţ�ʱ��ռ�ܻʱ���%
local AMatchConfig = {

-- ����һ
[1]={ activity={ 1,3,4,2,5 }, timescale={ 0.142857, 0.142857, 0.142857, 0.142857, 0.42857 } },

[2]={ activity={ 4,1,3,2,5 }, timescale={ 0.142857, 0.142857, 0.142857, 0.142857, 0.42857 } },

[3]={ activity={ 1,4,2,2,5 }, timescale={ 0.142857, 0.142857, 0.142857, 0.142857, 0.42857 } },

[4]={ activity={ 1,3,1,3,4 }, timescale={ 0.142857, 0.142857, 0.142857, 0.142857,0.142857 } },

[5]={ activity={ 3,1,3,1,4 }, timescale={ 0.2, 0.2, 0.2, 0.2, 0.2 } },

[6]={ activity={ 1,2,4,2,5 }, timescale={ 0.1677778,0.1677778,0.1677778,0.1677778,0.3288888} },
}

function IN_AMatchGetActivity( configid, stage )
	if AMatchConfig[configid] == nil then
		return AMatchConfig[1]["activity"][stage];
	end
	return AMatchConfig[configid]["activity"][stage];
end

function IN_AMatchGetStartTime( configid, stage, activity_starttime, activity_lefttime )
	if AMatchConfig[configid] == nil then
		return activity_starttime;
	end
	local timeTable = {0,0,0,0,0};
	for i=1, 5, 1 do
		timeTable[i] = AMatchConfig[configid]["timescale"][i] * activity_lefttime;
	end
	
	if stage == 1 then
		return activity_starttime;
	elseif stage == 2 then
		return activity_starttime + timeTable[1];
	elseif stage == 3 then
		return activity_starttime + timeTable[1] + timeTable[2];
	elseif stage == 4 then
		return activity_starttime + timeTable[1] + timeTable[2] + timeTable[3];
	elseif stage == 5 then
		return activity_starttime + timeTable[1] + timeTable[2] + timeTable[3] + timeTable[4];
	end
	return activity_starttime;
end

-- ÿһ���ӻ��Ӧ����������Ŀ�꽱��
local AMatchPointTarget = { 
-- �ɼ�����
[1] = { 
[1] = { point = { 22500, 45000, 90000}, kind = { 302, 290, 100005,}, num ={ 1, 3, 200} },
[2] = { point = { 30000, 60000, 120000}, kind = { 302, 290, 100005,}, num ={ 1, 3, 210} },
[3] = { point = { 37500, 75000, 150000}, kind = { 302, 290, 100005,}, num ={ 1, 3, 220} },
[4] = { point = { 45000, 90000, 180000}, kind = { 302, 290, 100005,}, num ={ 1, 3, 230} },
[5] = { point = { 75000, 150000, 300000}, kind = { 302, 290, 100005,}, num ={ 1, 3, 240} },
[6] = { point = { 112500, 225000, 450000}, kind = { 302, 290, 100005,}, num ={ 1, 3, 250} },
[7] = { point = { 150000, 300000, 600000}, kind = { 302, 290, 100005,}, num ={ 1, 3, 260} },
[8] = { point = { 187500, 375000, 750000}, kind = { 302, 290, 100005,}, num ={ 1, 3, 270} },
[9] = { point = { 225000, 450000, 900000}, kind = { 302, 290, 100005,}, num ={ 2, 3, 280} },
[10] = { point = { 318750, 637500, 1275000}, kind = { 302, 290, 100005,}, num ={ 2, 3, 290} },
[11] = { point = { 450000, 900000, 1800000}, kind = { 302, 290, 100005,}, num ={ 2, 3, 300} },
[12] = { point = { 581250, 1162500, 2325000}, kind = { 302, 290, 100005,}, num ={ 2, 3, 310} },
[13] = { point = { 712500, 1425000, 2850000}, kind = { 302, 290, 100005,}, num ={ 2, 3, 320} },
[14] = { point = { 843750, 1687500, 3375000}, kind = { 302, 290, 100005,}, num ={ 3, 3, 330} },
[15] = { point = { 975000, 1950000, 3900000}, kind = { 302, 290, 100005,}, num ={ 3, 3, 340} },
[16] = { point = { 1106250, 2212500, 4425000}, kind = { 302, 290, 100005,}, num ={ 3, 3, 350} },
[17] = { point = { 1237500, 2475000, 4950000}, kind = { 302, 290, 100005,}, num ={ 3, 3, 360} },
[18] = { point = { 1368750, 2737500, 5475000}, kind = { 302, 290, 100005,}, num ={ 3, 3, 370} },
[19] = { point = { 1500000, 3000000, 6000000}, kind = { 302, 290, 100005,}, num ={ 3, 3, 380} },
[20] = { point = { 1547500, 3095000, 6190000}, kind = { 302, 290, 100005,}, num ={ 4, 3, 390} },
[21] = { point = { 1595000, 3190000, 6380000}, kind = { 302, 290, 100005,}, num ={ 4, 3, 400} },
[22] = { point = { 1642500, 3285000, 6570000}, kind = { 302, 290, 100005,}, num ={ 4, 3, 410} },
[23] = { point = { 1690000, 3380000, 6760000}, kind = { 302, 290, 100005,}, num ={ 4, 3, 420} },
[24] = { point = { 1737500, 3475000, 6950000}, kind = { 302, 290, 100005,}, num ={ 4, 3, 430} },
[25] = { point = { 1785000, 3570000, 7140000}, kind = { 302, 290, 100005,}, num ={ 4, 3, 440} },
[26] = { point = { 1832500, 3665000, 7330000}, kind = { 302, 290, 100005,}, num ={ 4, 3, 450} },
[27] = { point = { 1880000, 3760000, 7520000}, kind = { 302, 290, 100005,}, num ={ 5, 3, 460} },
[28] = { point = { 1927500, 3855000, 7710000}, kind = { 302, 290, 100005,}, num ={ 5, 3, 470} },
[29] = { point = { 1975000, 3950000, 7900000}, kind = { 302, 290, 100005,}, num ={ 5, 3, 480} },
[30] = { point = { 2022500, 4045000, 8090000}, kind = { 302, 290, 100005,}, num ={ 5, 3, 490} },
},
-- �������
[2] = { 
[1] = { point = { 18500, 37000, 74000}, kind = { 299, 107, 100005,}, num ={ 1, 2, 200} },
[2] = { point = { 29600, 59200, 118400}, kind = { 299, 107, 100005,}, num ={ 1, 2, 210} },
[3] = { point = { 40700, 81400, 162800}, kind = { 299, 107, 100005,}, num ={ 1, 2, 220} },
[4] = { point = { 51800, 103600, 207200}, kind = { 299, 107, 100005,}, num ={ 1, 2, 230} },
[5] = { point = { 62900, 125800, 251600}, kind = { 299, 107, 100005,}, num ={ 1, 2, 240} },
[6] = { point = { 74000, 148000, 296000}, kind = { 299, 107, 100005,}, num ={ 1, 2, 250} },
[7] = { point = { 92500, 185000, 370000}, kind = { 299, 107, 100005,}, num ={ 1, 2, 260} },
[8] = { point = { 138750, 277500, 555000}, kind = { 299, 107, 100005,}, num ={ 1, 2, 270} },
[9] = { point = { 166500, 333000, 666000}, kind = { 299, 107, 100005,}, num ={ 2, 2, 280} },
[10] = { point = { 235875, 471750, 943500}, kind = { 299, 107, 100005,}, num ={ 2, 2, 290} },
[11] = { point = { 333000, 666000, 1332000}, kind = { 299, 107, 100005,}, num ={ 2, 2, 300} },
[12] = { point = { 430125, 860250, 1720500}, kind = { 299, 107, 100005,}, num ={ 2, 2, 310} },
[13] = { point = { 527250, 1054500, 2109000}, kind = { 299, 107, 100005,}, num ={ 2, 2, 320} },
[14] = { point = { 624375, 1248750, 2497500}, kind = { 299, 107, 100005,}, num ={ 3, 2, 330} },
[15] = { point = { 721500, 1443000, 2886000}, kind = { 299, 107, 100005,}, num ={ 3, 2, 340} },
[16] = { point = { 818625, 1637250, 3274500}, kind = { 299, 107, 100005,}, num ={ 3, 2, 350} },
[17] = { point = { 915750, 1831500, 3663000}, kind = { 299, 107, 100005,}, num ={ 3, 2, 360} },
[18] = { point = { 1012875, 2025750, 4051500}, kind = { 299, 107, 100005,}, num ={ 4, 2, 370} },
[19] = { point = { 1110000, 2220000, 4440000}, kind = { 299, 107, 100005,}, num ={ 4, 2, 380} },
[20] = { point = { 1147000, 2294000, 4588000}, kind = { 299, 107, 100005,}, num ={ 4, 2, 390} },
[21] = { point = { 1184000, 2368000, 4736000}, kind = { 299, 107, 100005,}, num ={ 4, 2, 400} },
[22] = { point = { 1221000, 2442000, 4884000}, kind = { 299, 107, 100005,}, num ={ 5, 2, 410} },
[23] = { point = { 1258000, 2516000, 5032000}, kind = { 299, 107, 100005,}, num ={ 5, 2, 420} },
[24] = { point = { 1295000, 2590000, 5180000}, kind = { 299, 107, 100005,}, num ={ 5, 2, 430} },
[25] = { point = { 1332000, 2664000, 5328000}, kind = { 299, 107, 100005,}, num ={ 5, 2, 440} },
[26] = { point = { 1369000, 2738000, 5476000}, kind = { 299, 107, 100005,}, num ={ 6, 2, 450} },
[27] = { point = { 1406000, 2812000, 5624000}, kind = { 299, 107, 100005,}, num ={ 6, 2, 460} },
[28] = { point = { 1443000, 2886000, 5772000}, kind = { 299, 107, 100005,}, num ={ 6, 2, 470} },
[29] = { point = { 1480000, 2960000, 5920000}, kind = { 299, 107, 100005,}, num ={ 6, 2, 480} },
[30] = { point = { 1517000, 3034000, 6068000}, kind = { 299, 107, 100005,}, num ={ 6, 2, 490} },
},
-- �������Ƽ�ս������
[3] = { 
[1] = { point = { 50000, 100000, 200000}, kind = { 300, 250, 100005,}, num ={ 1, 1, 200} },
[2] = { point = { 50000, 100000, 200000}, kind = { 300, 250, 100005,}, num ={ 1, 2, 210} },
[3] = { point = { 50000, 100000, 200000}, kind = { 300, 250, 100005,}, num ={ 1, 3, 220} },
[4] = { point = { 50000, 100000, 200000}, kind = { 300, 250, 100005,}, num ={ 1, 4, 230} },
[5] = { point = { 50000, 100000, 200000}, kind = { 300, 250, 100005,}, num ={ 1, 5, 240} },
[6] = { point = { 50000, 100000, 200000}, kind = { 300, 250, 100005,}, num ={ 1, 6, 250} },
[7] = { point = { 52500, 105000, 210000}, kind = { 300, 250, 100005,}, num ={ 1, 7, 260} },
[8] = { point = { 55000, 110000, 220000}, kind = { 300, 250, 100005,}, num ={ 1, 8, 270} },
[9] = { point = { 58750, 117500, 235000}, kind = { 300, 250, 100005,}, num ={ 2, 9, 280} },
[10] = { point = { 62500, 125000, 250000}, kind = { 300, 250, 100005,}, num ={ 2, 10, 290} },
[11] = { point = { 68712, 137425, 274850}, kind = { 300, 250, 100005,}, num ={ 2, 11, 300} },
[12] = { point = { 75420, 150841, 301683}, kind = { 300, 250, 100005,}, num ={ 2, 12, 310} },
[13] = { point = { 89020, 178041, 356083}, kind = { 300, 250, 100005,}, num ={ 2, 13, 320} },
[14] = { point = { 99533, 199066, 398133}, kind = { 300, 250, 100005,}, num ={ 3, 14, 330} },
[15] = { point = { 125116, 250233, 500466}, kind = { 300, 250, 100005,}, num ={ 3, 15, 340} },
[16] = { point = { 140404, 280808, 561616}, kind = { 300, 250, 100005,}, num ={ 3, 16, 350} },
[17] = { point = { 163783, 327566, 655133}, kind = { 300, 250, 100005,}, num ={ 3, 17, 360} },
[18] = { point = { 192766, 385533, 771066}, kind = { 300, 250, 100005,}, num ={ 4, 18, 370} },
[19] = { point = { 231708, 463416, 926833}, kind = { 300, 250, 100005,}, num ={ 4, 19, 380} },
[20] = { point = { 278341, 556683, 1113366}, kind = { 300, 250, 100005,}, num ={ 4, 20, 390} },
[21] = { point = { 324795, 649591, 1299183}, kind = { 300, 250, 100005,}, num ={ 4, 21, 400} },
[22] = { point = { 342533, 685066, 1370133}, kind = { 300, 250, 100005,}, num ={ 5, 22, 410} },
[23] = { point = { 400200, 800400, 1600800}, kind = { 300, 250, 100005,}, num ={ 5, 23, 420} },
[24] = { point = { 465800, 931600, 1863200}, kind = { 300, 250, 100005,}, num ={ 5, 24, 430} },
[25] = { point = { 530583, 1061166, 2122333}, kind = { 300, 250, 100005,}, num ={ 5, 25, 440} },
[26] = { point = { 595087, 1190175, 2380350}, kind = { 300, 250, 100005,}, num ={ 6, 26, 450} },
[27] = { point = { 659666, 1319333, 2638666}, kind = { 300, 250, 100005,}, num ={ 6, 27, 460} },
[28] = { point = { 724550, 1449100, 2898200}, kind = { 300, 250, 100005,}, num ={ 6, 28, 470} },
[29] = { point = { 789904, 1579808, 3159616}, kind = { 300, 250, 100005,}, num ={ 6, 29, 480} },
[30] = { point = { 855845, 1711691, 3423383}, kind = { 300, 250, 100005,}, num ={ 6, 30, 490} },
},
-- ɱҰ��
[4] = { 
[1] = { point = { 21924, 43848, 87696}, kind = { 301, 206, 100005,}, num ={ 1, 10, 200} },
[2] = { point = { 31597, 63195, 126391}, kind = { 301, 206, 100005,}, num ={ 1, 10, 210} },
[3] = { point = { 53773, 107547, 215095}, kind = { 301, 206, 100005,}, num ={ 1, 10, 220} },
[4] = { point = { 90735, 181470, 362941}, kind = { 301, 206, 100005,}, num ={ 1, 10, 230} },
[5] = { point = { 114599, 229199, 458399}, kind = { 301, 206, 100005,}, num ={ 1, 10, 240} },
[6] = { point = { 170955, 341910, 683820}, kind = { 301, 206, 100005,}, num ={ 1, 10, 250} },
[7] = { point = { 212469, 424939, 849878}, kind = { 301, 206, 100005,}, num ={ 1, 10, 260} },
[8] = { point = { 259118, 518236, 1036472}, kind = { 301, 206, 100005,}, num ={ 1, 10, 270} },
[9] = { point = { 322721, 645442, 1290885}, kind = { 301, 206, 100005,}, num ={ 2, 10, 280} },
[10] = { point = { 386132, 772265, 1544530}, kind = { 301, 206, 100005,}, num ={ 2, 10, 290} },
[11] = { point = { 443569, 887139, 1774278}, kind = { 301, 206, 100005,}, num ={ 2, 10, 300} },
[12] = { point = { 505727, 1011455, 2022911}, kind = { 301, 206, 100005,}, num ={ 2, 10, 310} },
[13] = { point = { 567100, 1134201, 2268403}, kind = { 301, 206, 100005,}, num ={ 2, 10, 320} },
[14] = { point = { 638740, 1277480, 2554960}, kind = { 301, 206, 100005,}, num ={ 3, 10, 330} },
[15] = { point = { 707878, 1415757, 2831515}, kind = { 301, 206, 100005,}, num ={ 3, 10, 340} },
[16] = { point = { 773506, 1547012, 3094024}, kind = { 301, 206, 100005,}, num ={ 3, 10, 350} },
[17] = { point = { 880499, 1760998, 3521996}, kind = { 301, 206, 100005,}, num ={ 3, 10, 360} },
[18] = { point = { 948558, 1897117, 3794235}, kind = { 301, 206, 100005,}, num ={ 4, 10, 370} },
[19] = { point = { 1021405, 2042810, 4085620}, kind = { 301, 206, 100005,}, num ={ 4, 10, 380} },
[20] = { point = { 1109307, 2218614, 4437229}, kind = { 301, 206, 100005,}, num ={ 4, 10, 390} },
[21] = { point = { 1194597, 2389194, 4778388}, kind = { 301, 206, 100005,}, num ={ 4, 10, 400} },
[22] = { point = { 1250816, 2501632, 5003265}, kind = { 301, 206, 100005,}, num ={ 5, 10, 410} },
[23] = { point = { 1316327, 2632654, 5265309}, kind = { 301, 206, 100005,}, num ={ 5, 10, 420} },
[24] = { point = { 1367274, 2734549, 5469098}, kind = { 301, 206, 100005,}, num ={ 5, 10, 430} },
[25] = { point = { 1439049, 2878099, 5756198}, kind = { 301, 206, 100005,}, num ={ 5, 10, 440} },
[26] = { point = { 1477207, 2954415, 5908831}, kind = { 301, 206, 100005,}, num ={ 6, 10, 450} },
[27] = { point = { 1533531, 3067063, 6134126}, kind = { 301, 206, 100005,}, num ={ 6, 10, 460} },
[28] = { point = { 1586723, 3173446, 6346893}, kind = { 301, 206, 100005,}, num ={ 6, 10, 470} },
[29] = { point = { 1642838, 3285676, 6571353}, kind = { 301, 206, 100005,}, num ={ 6, 10, 480} },
[30] = { point = { 1702920, 3405841, 6811682}, kind = { 301, 206, 100005,}, num ={ 6, 10, 490} },
},
-- ɱ��
[5] = { 
[1] = { point = { 42692, 111000, 296000}, kind = { 206, 202, 100005,}, num ={ 1, 1, 700} },
[2] = { point = { 68307, 177600, 473600}, kind = { 206, 202, 100005,}, num ={ 1, 1, 735} },
[3] = { point = { 93923, 244200, 651200}, kind = { 206, 202, 100005,}, num ={ 1, 1, 770} },
[4] = { point = { 119538, 310800, 828800}, kind = { 206, 202, 100005,}, num ={ 1, 1, 805} },
[5] = { point = { 145153, 377400, 1006400}, kind = { 206, 202, 100005,}, num ={ 1, 1, 840} },
[6] = { point = { 170769, 444000, 1184000}, kind = { 206, 202, 100005,}, num ={ 1, 1, 875} },
[7] = { point = { 213461, 555000, 1480000}, kind = { 206, 202, 100005,}, num ={ 1, 1, 910} },
[8] = { point = { 320192, 832500, 2220000}, kind = { 206, 202, 100005,}, num ={ 1, 1, 945} },
[9] = { point = { 384230, 999000, 2664000}, kind = { 206, 202, 100005,}, num ={ 1, 1, 980} },
[10] = { point = { 544326, 1415250, 3774000}, kind = { 206, 202, 100005,}, num ={ 1, 1, 1015} },
[11] = { point = { 768461, 1998000, 5328000}, kind = { 206, 202, 100005,}, num ={ 1, 1, 1050} },
[12] = { point = { 992596, 2580750, 6882000}, kind = { 206, 202, 100005,}, num ={ 1, 1, 1085} },
[13] = { point = { 1216730, 3163500, 8436000}, kind = { 206, 202, 100005,}, num ={ 1, 1, 1120} },
[14] = { point = { 1440865, 3746250, 9990000}, kind = { 206, 202, 100005,}, num ={ 1, 1, 1155} },
[15] = { point = { 1665000, 4329000, 11544000}, kind = { 206, 202, 100005,}, num ={ 1, 1, 1190} },
[16] = { point = { 1889134, 4911750, 13098000}, kind = { 206, 202, 100005,}, num ={ 1, 1, 1225} },
[17] = { point = { 2113269, 5494500, 14652000}, kind = { 206, 202, 100005,}, num ={ 2, 1, 1260} },
[18] = { point = { 2337403, 6077250, 16206000}, kind = { 206, 202, 100005,}, num ={ 2, 1, 1295} },
[19] = { point = { 2561538, 6660000, 17760000}, kind = { 206, 202, 100005,}, num ={ 2, 1, 1330} },
[20] = { point = { 2646923, 6882000, 18352000}, kind = { 206, 202, 100005,}, num ={ 2, 1, 1365} },
[21] = { point = { 2732307, 7104000, 18944000}, kind = { 206, 202, 100005,}, num ={ 2, 1, 1400} },
[22] = { point = { 2817692, 7326000, 19536000}, kind = { 206, 202, 100005,}, num ={ 2, 1, 1435} },
[23] = { point = { 2903076, 7548000, 20128000}, kind = { 206, 202, 100005,}, num ={ 3, 1, 1470} },
[24] = { point = { 2988461, 7770000, 20720000}, kind = { 206, 202, 100005,}, num ={ 3, 1, 1505} },
[25] = { point = { 3073846, 7992000, 21312000}, kind = { 206, 202, 100005,}, num ={ 3, 1, 1540} },
[26] = { point = { 3159230, 8214000, 21904000}, kind = { 206, 202, 100005,}, num ={ 3, 1, 1575} },
[27] = { point = { 3244615, 8436000, 22496000}, kind = { 206, 202, 100005,}, num ={ 3, 1, 1610} },
[28] = { point = { 3330000, 8658000, 23088000}, kind = { 206, 202, 100005,}, num ={ 3, 1, 1645} },
[29] = { point = { 3415384, 8880000, 23680000}, kind = { 206, 202, 100005,}, num ={ 3, 1, 1680} },
[30] = { point = { 3500769, 9102000, 24272000}, kind = { 206, 202, 100005,}, num ={ 3, 1, 1715} },
},
}
-- ��ȡ����Ŀ�꽱��
function IN_AMatchGetPointAward( childid, level, stagepoint, stepaward )
	if AMatchPointTarget[childid] == nil then
		return 0, 0, 0;
	end
	
	local info = AMatchPointTarget[childid][level];
	if info == nil then
		return 0, 0, 0;
	end

	for i=1, 3, 1 do
		if i > stepaward then
			if stagepoint >= info["point"][i] then
				return info["kind"][i], info["num"][i], info["point"][i];
			end
		end
	end
	return 0, 0, 0;
end


-- �׶���������
local AMatchStageRankAward = {	
-- �ɼ�����	
[1] = { 	
{ minrank = 1, maxrank = 1, awardgroup = 1120 }, 	
{ minrank = 2, maxrank = 2, awardgroup = 1121 }, 	
{ minrank = 3, maxrank = 3, awardgroup = 1122 }, 	
{ minrank = 4, maxrank = 4, awardgroup = 1123 }, 	
{ minrank = 5, maxrank = 5, awardgroup = 1124 }, 	
{ minrank = 6, maxrank = 6, awardgroup = 1125 }, 	
{ minrank = 7, maxrank = 7, awardgroup = 1126 }, 	
{ minrank = 8, maxrank = 8, awardgroup = 1127 }, 	
{ minrank = 9, maxrank = 9, awardgroup = 1128 }, 	
{ minrank = 10, maxrank = 10, awardgroup = 1129 }, 	
{ minrank = 11, maxrank = 15, awardgroup = 1130 }, 	
{ minrank = 16, maxrank = 20, awardgroup = 1131 }, 	
{ minrank = 21, maxrank = 30, awardgroup = 1132 }, 	
{ minrank = 31, maxrank = 50, awardgroup = 1133 }, 	
{ minrank = 51, maxrank = 100, awardgroup = 1134 },},
	
-- �������	
[2] = { 	
{ minrank = 1, maxrank = 1, awardgroup = 1140 }, 	
{ minrank = 2, maxrank = 2, awardgroup = 1141 }, 	
{ minrank = 3, maxrank = 3, awardgroup = 1142 }, 	
{ minrank = 4, maxrank = 4, awardgroup = 1143 }, 	
{ minrank = 5, maxrank = 5, awardgroup = 1144 }, 	
{ minrank = 6, maxrank = 6, awardgroup = 1145 }, 	
{ minrank = 7, maxrank = 7, awardgroup = 1146 }, 	
{ minrank = 8, maxrank = 8, awardgroup = 1147 }, 	
{ minrank = 9, maxrank = 9, awardgroup = 1148 }, 	
{ minrank = 10, maxrank = 10, awardgroup = 1149 }, 	
{ minrank = 11, maxrank = 15, awardgroup = 1150 }, 	
{ minrank = 16, maxrank = 20, awardgroup = 1151 }, 	
{ minrank = 21, maxrank = 30, awardgroup = 1152 }, 	
{ minrank = 31, maxrank = 50, awardgroup = 1153 }, 	
{ minrank = 51, maxrank = 100, awardgroup = 1154 },},
	
-- ս������	
[3] = { 	
{ minrank = 1, maxrank = 1, awardgroup = 1160 }, 	
{ minrank = 2, maxrank = 2, awardgroup = 1161 }, 	
{ minrank = 3, maxrank = 3, awardgroup = 1162 }, 	
{ minrank = 4, maxrank = 4, awardgroup = 1163 }, 	
{ minrank = 5, maxrank = 5, awardgroup = 1164 }, 	
{ minrank = 6, maxrank = 6, awardgroup = 1165 }, 	
{ minrank = 7, maxrank = 7, awardgroup = 1166 }, 	
{ minrank = 8, maxrank = 8, awardgroup = 1167 }, 	
{ minrank = 9, maxrank = 9, awardgroup = 1168 }, 	
{ minrank = 10, maxrank = 10, awardgroup = 1169 }, 	
{ minrank = 11, maxrank = 15, awardgroup = 1170 }, 	
{ minrank = 16, maxrank = 20, awardgroup = 1171 }, 	
{ minrank = 21, maxrank = 30, awardgroup = 1172 }, 	
{ minrank = 31, maxrank = 50, awardgroup = 1173 }, 	
{ minrank = 51, maxrank = 100, awardgroup = 1174 },}, 	
	
-- ɱҰ������	
[4] = { 	
{ minrank = 1, maxrank = 1, awardgroup = 1180 }, 	
{ minrank = 2, maxrank = 2, awardgroup = 1181 }, 	
{ minrank = 3, maxrank = 3, awardgroup = 1182 }, 	
{ minrank = 4, maxrank = 4, awardgroup = 1183 }, 	
{ minrank = 5, maxrank = 5, awardgroup = 1184 }, 	
{ minrank = 6, maxrank = 6, awardgroup = 1185 }, 	
{ minrank = 7, maxrank = 7, awardgroup = 1186 }, 	
{ minrank = 8, maxrank = 8, awardgroup = 1187 }, 	
{ minrank = 9, maxrank = 9, awardgroup = 1188 }, 	
{ minrank = 10, maxrank = 10, awardgroup = 1189 }, 	
{ minrank = 11, maxrank = 15, awardgroup = 1190 }, 	
{ minrank = 16, maxrank = 20, awardgroup = 1191 }, 	
{ minrank = 21, maxrank = 30, awardgroup = 1192 }, 	
{ minrank = 31, maxrank = 50, awardgroup = 1193 }, 	
{ minrank = 51, maxrank = 100, awardgroup = 1194 },},
	
-- ɱ�������	
[5] = { 	
{ minrank = 1, maxrank = 1, awardgroup = 1200 }, 	
{ minrank = 2, maxrank = 2, awardgroup = 1201 }, 	
{ minrank = 3, maxrank = 3, awardgroup = 1202 }, 	
{ minrank = 4, maxrank = 4, awardgroup = 1203 }, 	
{ minrank = 5, maxrank = 5, awardgroup = 1204 }, 	
{ minrank = 6, maxrank = 6, awardgroup = 1205 }, 	
{ minrank = 7, maxrank = 7, awardgroup = 1206 }, 	
{ minrank = 8, maxrank = 8, awardgroup = 1207 }, 	
{ minrank = 9, maxrank = 9, awardgroup = 1208 }, 	
{ minrank = 10, maxrank = 10, awardgroup = 1209 }, 	
{ minrank = 11, maxrank = 15, awardgroup = 1210 }, 	
{ minrank = 16, maxrank = 20, awardgroup = 1211 }, 	
{ minrank = 21, maxrank = 30, awardgroup = 1212 }, 	
{ minrank = 31, maxrank = 50, awardgroup = 1213 }, 	
{ minrank = 51, maxrank = 100, awardgroup = 1214 },},
}
-- ��ȡ�׶���������
function IN_AMatchGetStageRankAward( childid, rank )
	local info = AMatchStageRankAward[childid];
	if info == nil then
		return 0;
	end
	for i, v in ipairs( info ) do
		if rank >= v.minrank and rank <= v.maxrank then
			return v.awardgroup;
		end
	end
	return 0;
end

--����������	
local AMatchTotalRankAward = {		
{ minrank = 1, maxrank = 1, awardgroup = 1100 }, 	
{ minrank = 2, maxrank = 2, awardgroup = 1101 }, 	
{ minrank = 3, maxrank = 3, awardgroup = 1102 }, 	
{ minrank = 4, maxrank = 4, awardgroup = 1103 }, 	
{ minrank = 5, maxrank = 5, awardgroup = 1104 }, 	
{ minrank = 6, maxrank = 6, awardgroup = 1105 }, 	
{ minrank = 7, maxrank = 7, awardgroup = 1106 }, 	
{ minrank = 8, maxrank = 8, awardgroup = 1107 }, 	
{ minrank = 9, maxrank = 9, awardgroup = 1108 }, 	
{ minrank = 10, maxrank = 10, awardgroup = 1109 }, 	
{ minrank = 11, maxrank = 15, awardgroup = 1110 }, 	
{ minrank = 16, maxrank = 20, awardgroup = 1111 }, 	
{ minrank = 21, maxrank = 30, awardgroup = 1112 }, 	
{ minrank = 31, maxrank = 50, awardgroup = 1113 }, 	
{ minrank = 51, maxrank = 100, awardgroup = 1114 }, 	
{ minrank = 101, maxrank = 200, awardgroup = 1115 }, 	
{ minrank = 201, maxrank = 500, awardgroup = 1116 }, 	
{ minrank = 501, maxrank = 1000, awardgroup = 1117 }, 
}
-- ��ȡ����������
function IN_AMatchGetTotalRankAward( rank )
	local info = AMatchTotalRankAward;
	if info == nil then
		return 0;
	end
	for i, v in ipairs( info ) do
		if rank >= v.minrank and rank <= v.maxrank then
			return v.awardgroup;
		end
	end
	return 0;
end




---------------------------------------- ѩ�˳�Ѩ ----------------------------------------------
function ShowDenOpen()
	ShowDenBrush( 1, 2500 );
	c_system_rollingmsg( 1, 0, "427" );
end

function ShowDenEnd()
	ShowDenBrush( 1, 0 );	
end

function ShowDenClose()
	ShowDenBrush( 1, 0 );
end

local ShowDenFrame = 0;
function ShowDenLogic()
	ShowDenFrame = ShowDenFrame + 1;
	if ShowDenFrame > 60 then
		ShowDenFrame = 0;
		ShowDenBrush( 0, 2500 );
		c_system_rollingmsg( 1, 0, "427" );
	end
end

-- ˢ��ÿСʱ
function ShowDenBrush( delete, num )
	local brushnum = num;
	
	-- ɾ��ѩ�˳�Ѩ
	if delete == 1 then
		for index = 0, g_map_activity_maxcount-1, 1 do
			local id, action, _,_,_, hp = c_map_activityinfo( index );
			local _, _, _, _, _, _, _, _, _, activityid = c_map_activityconfig( id );
			if id > 0 and action == 0 and activityid == ACTIVITY_SNOWDEN then
				c_map_activity_delete( index );
			end
		end		
	else	
		-- ����
		brushnum = brushnum - c_map_activity_getnum_withcondition( 20, ACTIVITY_SNOWDEN );
	end
		
	-- ��ˢ
	while brushnum > 0 do

		-- ���һ���հ׵�
		local posx, posy = c_map_getrandpos( -2 );
		local circleID = getCircleID( posx, posy );
		if circleID >= 2 and circleID <= 5 then
			c_map_activity_create( 20, posx, posy );
			brushnum = brushnum -1;
		end
		
	end
end
