-- �������
PAY_GOODSTYPE_BASE					=	0		-- �����̵�����
PAY_GOODSTYPE_PUSH					=	1		-- ��׼��������
PAY_GOODSTYPE_ACTION_PUSH			=	10		-- ��Ϊ��������
PAY_GOODSTYPE_ACTION_PUSH_MAX		=	30		-- ��Ϊ��������
PAY_GOODSTYPE_SYSTEM_SPEED			=	100		-- ϵͳ���ٽ�����������
PAY_GOODSTYPE_SYSTEM_RES_WOOD		=	101		-- ϵͳ��Դ��������������ͣ�ľ�ģ�
PAY_GOODSTYPE_SYSTEM_RES_FOOD		=	102		-- ϵͳ��Դ��������������ͣ�ʳ�
PAY_GOODSTYPE_SYSTEM_RES_IRON		=	103		-- ϵͳ��Դ��������������ͣ�����
PAY_GOODSTYPE_SYSTEM_RES_MITHRIL	=	104		-- ϵͳ��Դ��������������ͣ�������
PAY_GOODSTYPE_SYSTEM_TROOP_CALL		=	105		-- ļ��������������
PAY_GOODSTYPE_SYSTEM_TROOP_HEAL		=	106		-- ���ƽ�����������
PAY_GOODSTYPE_SYSTEM_CITYTECH		=	107		-- �Ƽ�������������
PAY_GOODSTYPE_SYSTEM_EQUIPFORGING	=	108		-- ���������������
PAY_GOODSTYPE_SYSTEM_TROOPFORGING	=   109		-- ����ǿ��������������
PAY_GOODSTYPE_ACTIVITY				=	200		-- �����

PAY_BUYSTATE_UP			= 1 -- ����״̬	��ǰ��Ҫ����Ҽ������͸��ߵ��ε����
PAY_BUYSTATE_PARALLEL	= 2 -- ����״̬ ��ǰ��Ҫ����Ҽ�������ͬ���ε����
PAY_BUYSTATE_DOWN		= 3 -- ����״̬	��ǰ��Ҫ����Ҽ������͸��͵��ε����

PAY_PUSHBAG_SCRIPTID 	= 1 -- ��ǰʹ�õĽű�

-- ��ǰ���Ͳ�����
-- ���������Ĳ���
-- �����������Ĳ���
local PushBagStrategy = {
[1] = { [PAY_BUYSTATE_UP] = { buy = PAY_BUYSTATE_UP, notbuy = PAY_BUYSTATE_PARALLEL}, [PAY_BUYSTATE_PARALLEL] = { buy= PAY_BUYSTATE_PARALLEL, notbuy = PAY_BUYSTATE_DOWN}, [PAY_BUYSTATE_DOWN] = { buy = PAY_BUYSTATE_UP,notbuy = PAY_BUYSTATE_PARALLEL},},
[2] = { [PAY_BUYSTATE_UP] = { buy = PAY_BUYSTATE_UP, notbuy = PAY_BUYSTATE_PARALLEL}, [PAY_BUYSTATE_PARALLEL] = { buy= PAY_BUYSTATE_PARALLEL, notbuy = PAY_BUYSTATE_DOWN}, [PAY_BUYSTATE_DOWN] = { buy = PAY_BUYSTATE_UP,notbuy = PAY_BUYSTATE_PARALLEL},},
}

-- ��׼�������
-- cd:δ����״̬�£��������Ĭ��ʱ�䳤�ȣ���λ�룩
-- up:������� 
-- parallel:������� 
-- down:�������
local PushBagList ={
[1] = {
[0]={cd=0, up=20, parallel=20, down=20},
[20]={cd=0, up=54, parallel=54, down=20},
[51]={cd=1800, up=52, parallel=56, down=56},
[52]={cd=14400, up=53, parallel=56, down=51},
[53]={cd=14400, up=54, parallel=57, down=52},
[54]={cd=14400, up=54, parallel=58, down=53},
[56]={cd=12600, up=57, parallel=53, down=56},
[57]={cd=14400, up=58, parallel=54, down=56},
[58]={cd=14400, up=58, parallel=54, down=57},
},

[2] = {
[0]={cd=0, up=11, parallel=11, down=11},
[51]={cd=0, up=13, parallel=111, down=11},
[22]={cd=60, up=13, parallel=112, down=11},
[53]={cd=60, up=113, parallel=113, down=12},
[111]={cd=60, up=113, parallel=111, down=111},
[112]={cd=60, up=113, parallel=113, down=111},
[113]={cd=60, up=12, parallel=12, down=112},
},
}

-- ��Ϊ�������-
local ActionBagList = { 

[10] = {
[0] = { next=401, cd=86400, limitcount=1 }, 
[401] = { next=402, cd=86400, limitcount=1 }, 
[402] = { next=403, cd=86400, limitcount=1 }, 
[403] = { next=404, cd=86400, limitcount=1 }, 
[404] = { next=405, cd=86400, limitcount=1 }, 
[405] = { next=406, cd=86400, limitcount=1 }, 
[406] = { next=406, cd=86400, limitcount=1 }, 
},

[11] = {
[0] = { next=411, cd=86400, limitcount=1 }, 
[411] = { next=412, cd=86400, limitcount=1 }, 
[412] = { next=413, cd=86400, limitcount=1 }, 
[413] = { next=414, cd=86400, limitcount=1 }, 
[414] = { next=415, cd=86400, limitcount=1 }, 
[415] = { next=416, cd=86400, limitcount=1 }, 
[416] = { next=416, cd=86400, limitcount=1 }, 
},

[12] = {
[0] = { next=421, cd=86400, limitcount=1 }, 
[421] = { next=422, cd=86400, limitcount=1 }, 
[422] = { next=423, cd=86400, limitcount=1 }, 
[423] = { next=424, cd=86400, limitcount=1 }, 
[424] = { next=425, cd=86400, limitcount=1 }, 
[425] = { next=426, cd=86400, limitcount=1 }, 
[426] = { next=426, cd=86400, limitcount=1 }, 
},

[13] = {
[0] = { next=431, cd=86400, limitcount=1 }, 
[431] = { next=432, cd=86400, limitcount=1 }, 
[432] = { next=433, cd=86400, limitcount=1 }, 
[433] = { next=434, cd=86400, limitcount=1 }, 
[434] = { next=435, cd=86400, limitcount=1 }, 
[435] = { next=436, cd=86400, limitcount=1 }, 
[436] = { next=436, cd=86400, limitcount=1 }, 
},

[19] = {
[0] = { next=491, cd=86400, limitcount=1 }, 
[491] = { next=492, cd=86400, limitcount=1 }, 
[492] = { next=493, cd=86400, limitcount=1 }, 
[493] = { next=494, cd=86400, limitcount=1 }, 
[494] = { next=495, cd=86400, limitcount=1 }, 
[495] = { next=496, cd=86400, limitcount=1 }, 
[496] = { next=496, cd=86400, limitcount=1 }, 
},

[17] = {
[0] = { next=471, cd=86400, limitcount=1 }, 
[471] = { next=472, cd=86400, limitcount=1 }, 
[472] = { next=473, cd=86400, limitcount=1 }, 
[473] = { next=474, cd=86400, limitcount=1 }, 
[474] = { next=475, cd=86400, limitcount=1 }, 
[475] = { next=476, cd=86400, limitcount=1 }, 
[476] = { next=476, cd=86400, limitcount=1 }, 
},

[21] = {
[0] = { next=511, cd=86400, limitcount=1 }, 
[511] = { next=512, cd=86400, limitcount=1 }, 
[512] = { next=513, cd=86400, limitcount=1 }, 
[513] = { next=514, cd=86400, limitcount=1 }, 
[514] = { next=515, cd=86400, limitcount=1 }, 
[515] = { next=516, cd=86400, limitcount=1 }, 
[516] = { next=516, cd=86400, limitcount=1 }, 
},
}


-- ���������������
local BuildSpeedBagList = { 
[0] = { next=302 }, 
[302] = { next=303 }, 
[303] = { next=304 }, 
[304] = { next=305 }, 
[305] = { next=306 }, 
[306] = { next=306 }, 
};

-- ��Դ�����������
local ResBagList = { 
[0]={
	[0] = { next=312 },  
	[312] = { next=313 }, 
	[313] = { next=314 }, 
	[314] = { next=315 }, 
	[315] = { next=316 }, 
	[316] = { next=316 }, 
	},
[1]={
	[0] = { next=322 }, 
	[322] = { next=323 }, 
	[323] = { next=324 }, 
	[324] = { next=325 }, 
	[325] = { next=326 }, 
	[326] = { next=326 }, 
	},
[2]={
	[0] = { next=332 }, 
	[332] = { next=333 }, 
	[333] = { next=334 }, 
	[334] = { next=335 }, 
	[335] = { next=336 }, 
	[336] = { next=336 }, 
	},
[3]={
	[0] = { next=342 }, 
	[342] = { next=343 }, 
	[343] = { next=344 }, 
	[344] = { next=345 }, 
	[345] = { next=346 }, 
	[346] = { next=346 }, 
	},
};

-- ļ�����
local CallBagList = { 
[0] = { next=352 }, 
[352] = { next=353 }, 
[353] = { next=354 }, 
[354] = { next=355 }, 
[355] = { next=356 }, 
[356] = { next=356 }, 
};

-- �������
local HealBagList = { 
[0] = { next=362 },  
[362] = { next=363 }, 
[363] = { next=364 }, 
[364] = { next=365 }, 
[365] = { next=366 }, 
[366] = { next=366 }, 
};

-- �Ƽ����
local TechBagList = { 
[0] = { next=372 }, 
[372] = { next=373 }, 
[373] = { next=374 }, 
[374] = { next=375 }, 
[375] = { next=376 }, 
[376] = { next=376 }, 
};

-- �������
local ForgingBagList = { 
[0] = { next=382 }, 
[382] = { next=383 }, 
[383] = { next=384 }, 
[384] = { next=385 }, 
[385] = { next=386 }, 
[386] = { next=386 }, 
};

-- �������
local TroopForgingBagList = { 
[0] = { next=392 }, 
[392] = { next=393 }, 
[393] = { next=394 }, 
[394] = { next=395 }, 
[395] = { next=396 }, 
[396] = { next=396 }, 
};

-- �ֲ�ͼ���
local PayBagDefaultList = { 
[1] = {1003,1006,1082,1113},
[2] = {1003,1006,1082,1113},
[3] = {1003,1006,1082,1113},
[4] = {1003,1006,1082,1113},
[5] = {1003,1006,1082,1113},
[6] = {1003,1006,1082,1113},
[7] = {1003,1006,1082,1113,1143,1146},
[8] = {1003,1006,1083,1122,1115,1146},
[9] = {1003,1006,1083,1122,1115,1146},
[10] = {1013,1016,1083,1122,1115,1146},
[11] = {1013,1016,1083,1124,1112,1146},
[12] = {1013,1016,1083,1124,1112,1146},
[13] = {1013,1016,1082,1124,1112,1146},
[14] = {1013,1016,1082,1124,1112,1146},
[15] = {1023,1026,1082,1124,1112,1146},
[16] = {1023,1026,1082,1125,1112,1146},
[17] = {1023,1026,1082,1125,1112,1146},
[18] = {1023,1026,1082,1125,1112,1146},
[19] = {1023,1026,1082,1125,1114,1146},
[20] = {1023,1026,1082,1125,1114,1146},
[21] = {1023,1026,1082,1125,1114,1146},
[22] = {1023,1026,1082,1125,1114,1146},
[23] = {1023,1026,1082,1125,1114,1146},
[24] = {1023,1026,1082,1125,1114,1146},
[25] = {1023,1026,1082,1125,1114,1146},
[26] = {1023,1026,1082,1125,1114,1146},
[27] = {1023,1026,1082,1125,1114,1146},
[28] = {1023,1026,1082,1125,1114,1146},
[29] = {1023,1026,1082,1125,1114,1146},
[30] = {1023,1026,1082,1125,1114,1146},
};

function IN_PushBagUpdate( PlayerIdx )
	NewPushBagList( PlayerIdx )
end

-- ��׼�������
function NewPushBagList( PlayerIdx )
	local goodsid, endtime, strategy = c_actor_getpushgoodsid( PlayerIdx );
	if goodsid <= 0 or PushBagList[PAY_PUSHBAG_SCRIPTID][goodsid] == nil then
		goodsid = PushBagList[PAY_PUSHBAG_SCRIPTID][0]["parallel"];
		c_actor_setpushgoodsid( PlayerIdx, goodsid, PushBagList[PAY_PUSHBAG_SCRIPTID][goodsid]["cd"], PAY_BUYSTATE_PARALLEL );
	
	-- ��CDʱ�䣬���ҵ�����	
	elseif endtime > 0 and os.time() > endtime then
		
		local next_goodsid = 0;
		local next_cd = 0;
		
		-- �����������
		local next_strategy = PushBagStrategy[PAY_PUSHBAG_SCRIPTID][strategy]["notbuy"];
		
		-- ��һ�����
		if next_strategy == PAY_BUYSTATE_UP then
			next_goodsid = PushBagList[PAY_PUSHBAG_SCRIPTID][goodsid]["up"];

		elseif next_strategy == PAY_BUYSTATE_PARALLEL then
			next_goodsid = PushBagList[PAY_PUSHBAG_SCRIPTID][goodsid]["parallel"];

		elseif next_strategy == PAY_BUYSTATE_DOWN then
			next_goodsid = PushBagList[PAY_PUSHBAG_SCRIPTID][goodsid]["down"];

		end
		
		-- ����ʱ��
		next_cd = PushBagList[PAY_PUSHBAG_SCRIPTID][next_goodsid]["cd"];
		-- ���õ�ǰ�������
		c_actor_setpushgoodsid( PlayerIdx, next_goodsid, next_cd, next_strategy );
	end
end

-- ���ͼ������
function NewPushBuildSpeedBagList( PlayerIdx )
	local goodsid = c_actor_building_getpushgoodsid( PlayerIdx );
	if goodsid <= 0 then
		c_actor_building_setpushgoodsid( PlayerIdx, BuildSpeedBagList[0]["next"] );
	end
end

-- ������Դ���
function NewPushResBagList( PlayerIdx )
	for i=0, 3, 1 do
		local goodsid = c_actor_res_getpushgoodsid( PlayerIdx, i );
		if goodsid <= 0 then
			c_actor_res_setpushgoodsid( PlayerIdx, i, ResBagList[i][0]["next"] );
		end
	end
end

-- ����ļ�����
function NewPushCallBagList( PlayerIdx )
	local goodsid = c_actor_call_getpushgoodsid( PlayerIdx );
	if goodsid <= 0 then
		c_actor_call_setpushgoodsid( PlayerIdx, CallBagList[0]["next"] );
	end
end

-- �����������
function NewPushHealBagList( PlayerIdx )
	local goodsid = c_actor_heal_getpushgoodsid( PlayerIdx );
	if goodsid <= 0 then
		c_actor_heal_setpushgoodsid( PlayerIdx, HealBagList[0]["next"] );
	end
end

-- ���ͿƼ����
function NewPushTechBagList( PlayerIdx )
	local goodsid = c_actor_tech_getpushgoodsid( PlayerIdx );
	if goodsid <= 0 then
		c_actor_tech_setpushgoodsid( PlayerIdx, TechBagList[0]["next"] );
	end
end

-- ���Ͷ������
function NewPushForgingBagList( PlayerIdx )
	local goodsid = c_actor_forging_getpushgoodsid( PlayerIdx );
	if goodsid <= 0 then
		c_actor_forging_setpushgoodsid( PlayerIdx, ForgingBagList[0]["next"] );
	end
end

-- ���ͱ������
function NewPushTroopForgingBagList( PlayerIdx )
	local goodsid = c_actor_troopforging_getpushgoodsid( PlayerIdx );
	if goodsid <= 0 then
		c_actor_troopforging_setpushgoodsid( PlayerIdx, TroopForgingBagList[0]["next"] );
	end
end

-- �����ֲ�ͼ���
function NewPushDefault( PlayerIdx )
	local cd = 7*86400;
	local lastcd = c_actor_get_uselimit_cd( PlayerIdx, 6 );
	if lastcd <= 0 then
		local city_index = c_actor_cityindex( PlayerIdx );
		local level = c_city_getlevel( city_index );
		local info = PayBagDefaultList[level];
		if info ~= nil and #info > 0 then
			for i=1, #info, 1 do
				c_city_paybag_add( PlayerIdx, info[i], cd, 1, 1 );
			end
			c_actor_set_uselimit_cd( PlayerIdx, 6, cd );
		end
	end
end

-- ������һ�����
function IN_PushBagNextGoodsID( nType, GoodsID, Strategy )
	
	-- ��׼����
	if nType == PAY_GOODSTYPE_PUSH then
		local next_goodsid = 0;
		local next_cd = 0;
		local next_strategy = PAY_BUYSTATE_UP;
		
		if GoodsID <= 0 or PushBagList[PAY_PUSHBAG_SCRIPTID][GoodsID] == nil then
			
			next_goodsid = PushBagList[PAY_PUSHBAG_SCRIPTID][0]["up"];
			next_cd = PushBagList[PAY_PUSHBAG_SCRIPTID][next_goodsid]["cd"];
			
		else
			
			-- �����������
			next_strategy = PushBagStrategy[PAY_PUSHBAG_SCRIPTID][Strategy]["buy"];
			
			-- ��һ�����
			if next_strategy == PAY_BUYSTATE_UP then
				next_goodsid = PushBagList[PAY_PUSHBAG_SCRIPTID][GoodsID]["up"];

			elseif next_strategy == PAY_BUYSTATE_PARALLEL then
				next_goodsid = PushBagList[PAY_PUSHBAG_SCRIPTID][GoodsID]["parallel"];
				
			elseif next_strategy == PAY_BUYSTATE_DOWN then
				next_goodsid = PushBagList[PAY_PUSHBAG_SCRIPTID][GoodsID]["down"];

			end
			
			-- ����ʱ��
			next_cd = PushBagList[PAY_PUSHBAG_SCRIPTID][next_goodsid]["cd"];
		end
		return next_goodsid, next_cd, next_strategy;
		
	-- ��Ϊ�������
	elseif nType >= PAY_GOODSTYPE_ACTION_PUSH and nType <= PAY_GOODSTYPE_ACTION_PUSH_MAX then
		if GoodsID <= 0 or ActionBagList[nType] == nil or ActionBagList[nType][GoodsID] == nil then
			
			next_goodsid = ActionBagList[10][0]["next"];
			next_cd = ActionBagList[10][0]["cd"];
			next_limitcount = ActionBagList[10][0]["limitcount"];
		else
			next_goodsid = ActionBagList[nType][GoodsID]["next"];
			next_cd = ActionBagList[nType][GoodsID]["cd"];
			next_limitcount = ActionBagList[nType][GoodsID]["limitcount"];
		end			
		return next_goodsid, next_cd, next_limitcount;
		
	-- ���ͼ������
	elseif nType == PAY_GOODSTYPE_SYSTEM_SPEED then
		local next_goodsid = 0;
		if GoodsID <= 0 or BuildSpeedBagList[GoodsID] == nil then
			next_goodsid = BuildSpeedBagList[0]["next"];
		else
			next_goodsid = BuildSpeedBagList[GoodsID]["next"];
		end
		return next_goodsid, 0, 0;
		
	-- ������Դ�����ľ�ģ�
	elseif nType == PAY_GOODSTYPE_SYSTEM_RES_WOOD then
		local next_goodsid = 0;
		if GoodsID <= 0 or ResBagList[0][GoodsID] == nil then
			next_goodsid = ResBagList[0][0]["next"];
		else
			next_goodsid = ResBagList[0][GoodsID]["next"];
		end
		return next_goodsid, 0, 0;
	
	-- ������Դ�����ʳ�
	elseif nType == PAY_GOODSTYPE_SYSTEM_RES_FOOD then
		local next_goodsid = 0;
		if GoodsID <= 0 or ResBagList[1][GoodsID] == nil then
			next_goodsid = ResBagList[1][0]["next"];
		else
			next_goodsid = ResBagList[1][GoodsID]["next"];
		end
		return next_goodsid, 0, 0;
		
	-- ������Դ���������
	elseif nType == PAY_GOODSTYPE_SYSTEM_RES_IRON then
		local next_goodsid = 0;
		if GoodsID <= 0 or ResBagList[2][GoodsID] == nil then
			next_goodsid = ResBagList[2][0]["next"];
		else
			next_goodsid = ResBagList[2][GoodsID]["next"];
		end
		return next_goodsid, 0, 0;
			
	-- ������Դ�����������
	elseif nType == PAY_GOODSTYPE_SYSTEM_RES_MITHRIL then
		local next_goodsid = 0;
		if GoodsID <= 0 or ResBagList[3][GoodsID] == nil then
			next_goodsid = ResBagList[3][0]["next"];
		else
			next_goodsid = ResBagList[3][GoodsID]["next"];
		end
		return next_goodsid, 0, 0;
	
	elseif nType == PAY_GOODSTYPE_SYSTEM_TROOP_CALL then
		local next_goodsid = 0;
		if GoodsID <= 0 or CallBagList[GoodsID] == nil then
			next_goodsid = CallBagList[0]["next"];
		else
			next_goodsid = CallBagList[GoodsID]["next"];
		end
		return next_goodsid, 0, 0;

	elseif nType == PAY_GOODSTYPE_SYSTEM_TROOP_HEAL then
		local next_goodsid = 0;
		if GoodsID <= 0 or HealBagList[GoodsID] == nil then
			next_goodsid = HealBagList[0]["next"];
		else
			next_goodsid = HealBagList[GoodsID]["next"];
		end
		return next_goodsid, 0, 0;

	elseif nType == PAY_GOODSTYPE_SYSTEM_CITYTECH then
		local next_goodsid = 0;
		if GoodsID <= 0 or TechBagList[GoodsID] == nil then
			next_goodsid = TechBagList[0]["next"];
		else
			next_goodsid = TechBagList[GoodsID]["next"];
		end
		return next_goodsid, 0, 0;

	elseif nType == PAY_GOODSTYPE_SYSTEM_EQUIPFORGING then
		local next_goodsid = 0;
		if GoodsID <= 0 or ForgingBagList[GoodsID] == nil then
			next_goodsid = ForgingBagList[0]["next"];
		else
			next_goodsid = ForgingBagList[GoodsID]["next"];
		end
		return next_goodsid, 0, 0;
		
	elseif nType == PAY_GOODSTYPE_SYSTEM_TROOPFORGING then
		local next_goodsid = 0;
		if GoodsID <= 0 or TroopForgingBagList[GoodsID] == nil then
			next_goodsid = TroopForgingBagList[0]["next"];
		else
			next_goodsid = TroopForgingBagList[GoodsID]["next"];
		end
		return next_goodsid, 0, 0;
		
	elseif nType == PAY_GOODSTYPE_ACTIVITY then
	end
	
	return 0, 0, 0;
end

function IN_PushSystemBagGoodsID( PlayerIdx )
	--[[--��������
	c_actor_building_setpushgoodsid( PlayerIdx, BuildSpeedBagList[0]["next"] );
	
	--��Դ���
	for i=0, 3, 1 do
		if i == 0 then
			c_actor_res_setpushgoodsid( PlayerIdx, i, ResBagList[i][0]["next"] );
		elseif i == 1 then
			c_actor_res_setpushgoodsid( PlayerIdx, i, ResBagList[i][0]["next"] );
		elseif i == 2 then
			c_actor_res_setpushgoodsid( PlayerIdx, i, ResBagList[i][0]["next"] );
		else
			c_actor_res_setpushgoodsid( PlayerIdx, i, ResBagList[i][0]["next"] );
		end
	end
	--ļ�����
	c_actor_call_setpushgoodsid( PlayerIdx, CallBagList[0]["next"] );
	--�������
	c_actor_heal_setpushgoodsid( PlayerIdx, HealBagList[0]["next"] );
	--�Ƽ����
	c_actor_tech_setpushgoodsid( PlayerIdx, TechBagList[0]["next"] );
	--�������
	c_actor_forging_setpushgoodsid( PlayerIdx, ForgingBagList[0]["next"] );
	return 0;--]]
	
	--��������
	local build_goodsid = c_actor_building_getpushgoodsid( PlayerIdx );
	if build_goodsid > 301 then
		c_actor_building_setpushgoodsid( PlayerIdx, BuildSpeedBagList[0]["next"] );
	else
		c_actor_building_setpushgoodsid( PlayerIdx, BuildSpeedBagList[0]["next"] );
	end
	--��Դ���
	for i=0, 3, 1 do
		local res_goodsid = c_actor_res_getpushgoodsid( PlayerIdx, i );
		if i == 0 then
			if res_goodsid > 311 then 
				c_actor_res_setpushgoodsid( PlayerIdx, i, ResBagList[i][0]["next"] );
			else
				c_actor_res_setpushgoodsid( PlayerIdx, i, ResBagList[i][0]["next"] );
			end
		elseif i == 1 then
			if res_goodsid > 321 then 
				c_actor_res_setpushgoodsid( PlayerIdx, i, ResBagList[i][0]["next"] );
			else
				c_actor_res_setpushgoodsid( PlayerIdx, i, ResBagList[i][0]["next"] );
			end
		elseif i == 2 then
			if res_goodsid > 331 then 
				c_actor_res_setpushgoodsid( PlayerIdx, i, ResBagList[i][0]["next"] );
			else
				c_actor_res_setpushgoodsid( PlayerIdx, i, ResBagList[i][0]["next"] );
			end
		else
			if res_goodsid > 341 then 
				c_actor_res_setpushgoodsid( PlayerIdx, i, ResBagList[i][0]["next"] );
			else
				c_actor_res_setpushgoodsid( PlayerIdx, i, ResBagList[i][0]["next"] );
			end
		end
	end
	--ļ�����
	local call_goodsid = c_actor_call_getpushgoodsid( PlayerIdx );
	if call_goodsid > 351 then
		c_actor_call_setpushgoodsid( PlayerIdx, CallBagList[0]["next"] );
	else
		c_actor_call_setpushgoodsid( PlayerIdx, CallBagList[0]["next"] );
	end
	--�������
	local heal_goodsid = c_actor_heal_getpushgoodsid( PlayerIdx );
	if heal_goodsid > 361 then
		c_actor_heal_setpushgoodsid( PlayerIdx, HealBagList[0]["next"] );
	else
		c_actor_heal_setpushgoodsid( PlayerIdx, HealBagList[0]["next"] );
	end
	--�Ƽ����
	local tech_goodsid = c_actor_tech_getpushgoodsid( PlayerIdx );
	if tech_goodsid > 371 then
		c_actor_tech_setpushgoodsid( PlayerIdx, TechBagList[0]["next"] );
	else
		c_actor_tech_setpushgoodsid( PlayerIdx, TechBagList[0]["next"] );
	end
	--�������
	local forging_goodsid = c_actor_forging_getpushgoodsid( PlayerIdx );
	if forging_goodsid > 381 then
		c_actor_forging_setpushgoodsid( PlayerIdx, ForgingBagList[0]["next"] );
	else
		c_actor_forging_setpushgoodsid( PlayerIdx, ForgingBagList[0]["next"] );
	end
	--�������
	local troopforging_goodsid = c_actor_troopforging_getpushgoodsid( PlayerIdx );
	if troopforging_goodsid > 391 then
		c_actor_troopforging_setpushgoodsid( PlayerIdx, TroopForgingBagList[0]["next"] );
	else
		c_actor_troopforging_setpushgoodsid( PlayerIdx, TroopForgingBagList[0]["next"] );
	end
	return 0;
end
