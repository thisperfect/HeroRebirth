-- MySQL dump 10.13  Distrib 5.1.63, for unknown-linux-gnu (x86_64)
--
-- Host: localhost    Database: f_game
-- ------------------------------------------------------
-- Server version	5.1.63

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity`
--

DROP TABLE IF EXISTS `activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity` (
  `activityid` int(11) NOT NULL AUTO_INCREMENT,
  `starttime` int(11) NOT NULL DEFAULT '0',
  `endtime` int(11) NOT NULL DEFAULT '0',
  `closetime` int(11) NOT NULL DEFAULT '0' COMMENT '真正结束时间',
  `value0` int(11) NOT NULL DEFAULT '0',
  `value1` int(11) NOT NULL DEFAULT '0',
  `value2` int(11) NOT NULL DEFAULT '0',
  `value3` bigint(20) NOT NULL DEFAULT '0',
  `strvalue` varchar(255) NOT NULL DEFAULT '',
  `openstat` tinyint(3) NOT NULL DEFAULT '0' COMMENT '是否调用过open',
  `endstat` tinyint(3) NOT NULL DEFAULT '0' COMMENT '是否调用过end',
  PRIMARY KEY (`activityid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='已经通过计时器设定完毕的活动';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `activity_dragon_actorrank`
--

DROP TABLE IF EXISTS `activity_dragon_actorrank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_dragon_actorrank` (
  `id` int(11) NOT NULL DEFAULT '0',
  `sort` tinyint(3) NOT NULL DEFAULT '0' COMMENT '排序',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '名称',
  `point` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '分数',
  `optime` int(11) NOT NULL DEFAULT '0' COMMENT '时间',
  PRIMARY KEY (`id`,`sort`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='巨龙之怒个人积分排行榜';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `activity_dragon_clubrank`
--

DROP TABLE IF EXISTS `activity_dragon_clubrank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_dragon_clubrank` (
  `id` int(11) NOT NULL DEFAULT '0',
  `sort` tinyint(3) NOT NULL DEFAULT '0' COMMENT '排序',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '名称',
  `point` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '分数',
  `optime` int(11) NOT NULL DEFAULT '0' COMMENT '时间',
  PRIMARY KEY (`id`,`sort`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='巨龙之怒联盟积分排行榜';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `actor`
--

DROP TABLE IF EXISTS `actor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actor` (
  `actorid` int(11) NOT NULL DEFAULT '0' COMMENT '角色编号',
  `name` varchar(22) NOT NULL DEFAULT '' COMMENT '角色名称',
  `aclass` tinyint(3) NOT NULL DEFAULT '0' COMMENT '角色类型',
  `shape` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '形象',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '等级',
  `experience` bigint(20) NOT NULL DEFAULT '0' COMMENT '当前经验',
  `body` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '体力',
  `cityid` int(11) NOT NULL DEFAULT '0' COMMENT '城池id',
  `admin` smallint(6) NOT NULL DEFAULT '0' COMMENT '权限',
  `lastip` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0' COMMENT '上次进入游戏的IP',
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '角色创建时间',
  `forbidtime` int(11) NOT NULL DEFAULT '0' COMMENT '禁言时间',
  `token` int(11) NOT NULL DEFAULT '0' COMMENT '钻石',
  `total_charge` int(11) NOT NULL DEFAULT '0' COMMENT '总充值',
  `itemext` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '背包扩展格子',
  `chat_mask_list` varbinary(512) NOT NULL DEFAULT '0' COMMENT '聊天屏蔽列表',
  `event_rand_id` int(11) NOT NULL DEFAULT '0' COMMENT '随机事件ID 0代表没有',
  `event_rand_start` int(11) NOT NULL DEFAULT '0' COMMENT '随机事件其实时间',
  `event_rand_is_done` tinyint(3) NOT NULL DEFAULT '0' COMMENT '随机事件是否已经完成',
  `event_must_id` int(11) NOT NULL DEFAULT '0' COMMENT '必然事件ID',
  `event_must_start` int(11) NOT NULL DEFAULT '0' COMMENT '必然事件开始时间',
  `event_must_is_done` tinyint(3) NOT NULL DEFAULT '0' COMMENT '必然事件是否完成',
  `worker_endtime` int(11) NOT NULL DEFAULT '0' COMMENT '额外建筑工招募结束时间',
  `sflag` int(11) NOT NULL DEFAULT '0' COMMENT '标志位',
  `fdate` int(11) NOT NULL DEFAULT '0' COMMENT '上次刷新的日子',
  `today_char` varbinary(128) NOT NULL DEFAULT '' COMMENT 'char类型每日数据',
  `today_int0` int(11) NOT NULL DEFAULT '0' COMMENT 'int类型每日数据',
  `today_int1` int(11) NOT NULL DEFAULT '0',
  `today_int2` int(11) NOT NULL DEFAULT '0',
  `today_int3` int(11) NOT NULL DEFAULT '0',
  `today_int4` int(11) NOT NULL DEFAULT '0',
  `today_int5` int(11) NOT NULL DEFAULT '0',
  `today_int6` int(11) NOT NULL DEFAULT '0',
  `today_int7` int(11) NOT NULL DEFAULT '0',
  `cd0` int(11) NOT NULL DEFAULT '0' COMMENT 'CD',
  `cd1` int(11) NOT NULL DEFAULT '0',
  `cd2` int(11) NOT NULL DEFAULT '0',
  `cd3` int(11) NOT NULL DEFAULT '0',
  `cd4` int(11) NOT NULL DEFAULT '0',
  `cd5` int(11) NOT NULL DEFAULT '0',
  `cd6` int(11) NOT NULL DEFAULT '0',
  `cd7` int(11) NOT NULL DEFAULT '0',
  `config` binary(8) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0' COMMENT '玩家的配置',
  `monster_killlevel` tinyint(3) NOT NULL DEFAULT '0' COMMENT '玩家已经击杀的野外怪物级别',
  `savex` varbinary(64) NOT NULL DEFAULT '' COMMENT '收藏的位置',
  `savey` varbinary(64) NOT NULL DEFAULT '' COMMENT '收藏的位置',
  `savename` varbinary(1024) NOT NULL DEFAULT '' COMMENT '收藏的地点自定义名字',
  `savetype` varbinary(32) NOT NULL DEFAULT '' COMMENT '收藏的地点类型',
  `login_awardnum` tinyint(3) NOT NULL DEFAULT '0' COMMENT '登陆奖励次数',
  `login_awarddate` int(11) NOT NULL DEFAULT '0' COMMENT '登陆奖励上次领取日期',
  `login_awardkind` varbinary(32) NOT NULL DEFAULT '' COMMENT '登陆奖励',
  `login_awardcount` varbinary(32) NOT NULL DEFAULT '' COMMENT '登陆奖励',
  `teach` int(11) NOT NULL DEFAULT '0' COMMENT '引导完成',
  `wishing_freecount` smallint(6) NOT NULL DEFAULT '0' COMMENT '许愿池今天可使用的免费次数',
  `wishing_foodcount` smallint(6) NOT NULL DEFAULT '0' COMMENT '许愿池今天许愿食物的次数',
  `wishing_woodcount` smallint(6) NOT NULL DEFAULT '0' COMMENT '许愿池今天许愿的木材次数',
  `wishing_ironcount` smallint(6) NOT NULL DEFAULT '0' COMMENT '许愿池今天许愿铁矿的次数',
  `wishing_mithrilcount` smallint(6) NOT NULL DEFAULT '0' COMMENT '许愿池今天许愿的秘银次数',
  `wishing_fday` int(11) NOT NULL DEFAULT '0' COMMENT '许愿池上次使用天数',
  `liveness_complete` varbinary(32) NOT NULL DEFAULT '' COMMENT '活跃度今天完成次数',
  `liveness_data` varbinary(128) NOT NULL DEFAULT '' COMMENT '活跃度完成数量',
  `liveness_point` smallint(6) NOT NULL DEFAULT '0' COMMENT '活跃点数',
  `liveness_award` varbinary(16) NOT NULL DEFAULT '' COMMENT '活跃度奖励领取状态',
  `skillcd` varbinary(64) NOT NULL DEFAULT '' COMMENT '技能冷却',
  `dragon_stone` binary(16) NOT NULL DEFAULT '0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0' COMMENT '龙晶',
  `base_limitbuy` binary(8) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0' COMMENT '永久限购',
  `everyday_limitbuy` binary(8) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0' COMMENT '每日限购',
  `activity_limitbuy` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0' COMMENT '活动限购',
  `activity_limitbuy_flag` binary(64) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0' COMMENT '活动限购标示',
  `month_card_buyday` int(11) NOT NULL DEFAULT '0' COMMENT '月卡',
  `charge_dollar` float(9,2) NOT NULL DEFAULT '0.00' COMMENT '总充值美元',
  `push_goodsid` smallint(6) NOT NULL DEFAULT '0' COMMENT '推送的礼包',
  `push_goodsid_time` int(11) NOT NULL DEFAULT '0' COMMENT '推送的时间',
  `push_goodsid_strategy` tinyint(3) NOT NULL DEFAULT '0' COMMENT '当前推送策略',
  `push_speedbag_goodsid` smallint(6) NOT NULL DEFAULT '0' COMMENT '加速礼包推送',
  `push_resbag_goodsid0` smallint(6) NOT NULL DEFAULT '0' COMMENT '资源礼包推送',
  `push_resbag_goodsid1` smallint(6) NOT NULL DEFAULT '0' COMMENT '资源礼包推送',
  `push_resbag_goodsid2` smallint(6) NOT NULL DEFAULT '0' COMMENT '资源礼包推送',
  `push_resbag_goodsid3` smallint(6) NOT NULL DEFAULT '0' COMMENT '资源礼包推送',
  `firstbind` tinyint(3) NOT NULL DEFAULT '0' COMMENT '首次绑定',
  `material_bloodnum` int(11) NOT NULL DEFAULT '0' COMMENT '邪神之血',
  `cdkey1` int(11) NOT NULL DEFAULT '0' COMMENT '是否领取该批次兑换码0-31',
  `cdkey2` int(11) NOT NULL DEFAULT '0' COMMENT '是否领取该批次兑换码32-63',
  `cdkey3` int(11) NOT NULL DEFAULT '0' COMMENT '是否领取该批次兑换码64-95',
  `cdkey4` int(11) NOT NULL DEFAULT '0' COMMENT '是否领取该批次兑换码96-127',
  `wishing_bloodcount` smallint(6) NOT NULL DEFAULT '0' COMMENT '许愿池今日魔血采集次数',
  `egg_time` varbinary(32) NOT NULL DEFAULT '0' COMMENT '时空裂隙时间戳（不是奖励）',
  `pay_stage1_value` smallint(6) NOT NULL DEFAULT '0' COMMENT '阶段充值阶段（特惠礼包）',
  `stage1_award` varbinary(4) NOT NULL DEFAULT '' COMMENT '阶段充值礼包领取状态',
  `pay_stage2_value` smallint(6) NOT NULL DEFAULT '0' COMMENT '阶段充值阶段（精选礼包）',
  `stage2_award` varbinary(4) NOT NULL DEFAULT '' COMMENT '阶段充值礼包领取状态',
  `pay_stage3_value` smallint(6) NOT NULL DEFAULT '0' COMMENT '阶段充值阶段（尊享礼包）',
  `stage3_award` varbinary(4) NOT NULL DEFAULT '' COMMENT '阶段充值礼包领取状态',
  `goods_month_cards` varbinary(64) NOT NULL DEFAULT '' COMMENT '月卡礼包购买日期',
  `goods_week_cards` varbinary(64) NOT NULL DEFAULT '' COMMENT '周卡礼包购买日期',
  `activity_growup_state` varbinary(16) NOT NULL DEFAULT '' COMMENT '成长活动领取状态',
  `club_buildingres` int(11) NOT NULL DEFAULT '0' COMMENT '联盟建筑资源',
  `fivestar_pushtimes` tinyint(3) NOT NULL DEFAULT '0' COMMENT '五星评价推送',
  `blackmarket_id1` int(11) NOT NULL DEFAULT '0' COMMENT '黑市商品id1',
  `blackmarket_id2` int(11) NOT NULL DEFAULT '0' COMMENT '黑市商品id2',
  `blackmarket_id3` int(11) NOT NULL DEFAULT '0' COMMENT '黑市商品id3',
  `blackmarket_id4` int(11) NOT NULL DEFAULT '0' COMMENT '黑市商品id4',
  `push_callbag_goodsid` smallint(6) NOT NULL DEFAULT '0' COMMENT '募兵礼包推送',
  `push_healbag_goodsid` smallint(6) NOT NULL DEFAULT '0' COMMENT '治疗礼包推送',
  `push_techbag_goodsid` smallint(6) NOT NULL DEFAULT '0' COMMENT '科技礼包推送',
  `push_forgingbag_goodsid` smallint(6) NOT NULL DEFAULT '0' COMMENT '锻造礼包推送',
  `actionbag_goodsid` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0' COMMENT '行为推送礼包',
  `actionbag_endtime` binary(32) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0' COMMENT '行为推送礼包结束时间',
  `actionbag_count` binary(8) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0' COMMENT '行为推送礼包限制次数',
  `pay_maxtier` smallint(6) NOT NULL DEFAULT '0' COMMENT '单笔付费最高档次',
  `sevenday` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0' COMMENT '七日礼包领取状态',
  `sevenday_awardflag` binary(2) NOT NULL DEFAULT '\0\0' COMMENT '七日礼包终极礼包领取状态',
  `planes_power` int(11) NOT NULL DEFAULT '0' COMMENT '位面能量',
  `plev_maxid` bigint(20) NOT NULL DEFAULT '0' COMMENT '位面事件上次读取ID',
  `shareaward_num` tinyint(3) NOT NULL DEFAULT '0' COMMENT 'FB分享奖励领取次数',
  `headreview` tinyint(3) NOT NULL DEFAULT '0' COMMENT '当前头像状态',
  `festivalaward_time` binary(32) NOT NULL DEFAULT '0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0' COMMENT '节日奖励时间戳',
  `charge_point` float(9,2) NOT NULL DEFAULT '0.00' COMMENT '充值积分（可当人民币）',
  `hero_soul` int(11) NOT NULL DEFAULT '0' COMMENT '英魂',
  `bbsm` tinyint(3) NOT NULL DEFAULT '0' COMMENT '版主',
  `tfres` int(11) NOT NULL DEFAULT '0' COMMENT '恶魔之心',
  `tfdaynum` binary(10) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0' COMMENT '兵改每天次数',
  `push_tfbag_goodsid` smallint(6) NOT NULL DEFAULT '0' COMMENT '兵改礼包推送',
  `hammer_num` tinyint(3) NOT NULL DEFAULT '0' COMMENT '剩余锤子个数',
  `yoka_num` tinyint(3) NOT NULL DEFAULT '0' COMMENT '剩余砸蛋次数',
  `idle_goodsnum` tinyint(3) NOT NULL DEFAULT '0' COMMENT '城内点击物当前个数',
  `idle_time` tinyint(3) NOT NULL DEFAULT '0' COMMENT '城内点击物刷新间隔',
  `idle_clicknum` tinyint(3) NOT NULL DEFAULT '0' COMMENT '城内点击物今日点击总数',
  PRIMARY KEY (`actorid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `actor_hero`
--

DROP TABLE IF EXISTS `actor_hero`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actor_hero` (
  `actorid` int(11) NOT NULL DEFAULT '0' COMMENT '所属角色id',
  `offset` tinyint(3) NOT NULL DEFAULT '0' COMMENT '位置索引',
  `kind` smallint(6) NOT NULL DEFAULT '0' COMMENT '英雄种类',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '等级',
  `state` tinyint(3) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`actorid`,`offset`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `actor_item`
--

DROP TABLE IF EXISTS `actor_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actor_item` (
  `itemid` bigint(20) NOT NULL DEFAULT '0' COMMENT '物品id',
  `actorid` int(11) NOT NULL DEFAULT '0' COMMENT '角色ID',
  `offset` smallint(6) NOT NULL DEFAULT '0' COMMENT '物品所在位置',
  `kind` int(11) NOT NULL DEFAULT '0' COMMENT '物品种类',
  `num` smallint(6) NOT NULL DEFAULT '0' COMMENT '物品个数',
  `ability0` smallint(6) NOT NULL DEFAULT '0' COMMENT '属性',
  `ability1` smallint(6) NOT NULL DEFAULT '0' COMMENT '属性',
  `ability2` smallint(6) NOT NULL DEFAULT '0' COMMENT '属性',
  `ability3` smallint(6) NOT NULL DEFAULT '0' COMMENT '属性',
  `value0` int(11) NOT NULL DEFAULT '0' COMMENT '属性值',
  `value1` int(11) NOT NULL DEFAULT '0' COMMENT '属性值',
  `value2` int(11) NOT NULL DEFAULT '0' COMMENT '属性值',
  `value3` int(11) NOT NULL DEFAULT '0' COMMENT '属性值',
  `color_level` tinyint(4) NOT NULL DEFAULT '0' COMMENT '颜色等级',
  PRIMARY KEY (`itemid`),
  KEY `actorid` (`actorid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `actor_list`
--

DROP TABLE IF EXISTS `actor_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actor_list` (
  `actorid` int(11) NOT NULL DEFAULT '0' COMMENT '角色编号',
  `platid` int(11) NOT NULL DEFAULT '0' COMMENT '所属平台',
  `userid` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户编号',
  `username` varchar(64) NOT NULL DEFAULT '' COMMENT '用户名',
  `offset` int(11) NOT NULL DEFAULT '0' COMMENT '所在位置(0启用-1删除)',
  `online` tinyint(3) NOT NULL DEFAULT '0' COMMENT '1在线，0不在线',
  `name` varchar(22) NOT NULL DEFAULT '' COMMENT '角色名字',
  `aclass` tinyint(3) NOT NULL DEFAULT '0' COMMENT '角色类型',
  `level` smallint(6) NOT NULL DEFAULT '0' COMMENT '等级',
  `lock_time` int(11) NOT NULL DEFAULT '0' COMMENT '锁定角色时间戳(到此时间解锁)',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '角色创建时间',
  `delete_stoptime` int(11) NOT NULL DEFAULT '0' COMMENT '删除角色时间',
  `logout_time` int(11) NOT NULL DEFAULT '0' COMMENT '下线时间',
  `channelid` smallint(6) NOT NULL DEFAULT '0' COMMENT '渠道ID，每个平台对应自己的渠道',
  `optype` tinyint(3) NOT NULL DEFAULT '0' COMMENT '1:ios 2:android',
  `devdata` char(255) NOT NULL DEFAULT '' COMMENT '设备信息',
  PRIMARY KEY (`actorid`),
  UNIQUE KEY `name` (`name`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `actor_quest`
--

DROP TABLE IF EXISTS `actor_quest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actor_quest` (
  `actorid` int(11) NOT NULL DEFAULT '0',
  `complete_flag` varbinary(1024) NOT NULL DEFAULT '0',
  `award_getnum` smallint(6) NOT NULL DEFAULT '0' COMMENT '奖励领取次数',
  `award_getprogress` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`actorid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `attack_event_delay`
--

DROP TABLE IF EXISTS `attack_event_delay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attack_event_delay` (
  `index` int(11) NOT NULL DEFAULT '0',
  `eventid` int(11) NOT NULL DEFAULT '0' COMMENT '事件ID',
  `delay` int(11) NOT NULL DEFAULT '0' COMMENT '延迟倒计时',
  `cityid` int(11) NOT NULL DEFAULT '0' COMMENT '城池ID',
  PRIMARY KEY (`index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='攻城事件延迟的保存';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city` (
  `cityid` int(11) NOT NULL AUTO_INCREMENT,
  `laird_type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '领主类型',
  `laird_actorid` int(11) NOT NULL DEFAULT '0' COMMENT '领主角色编号',
  `laird_name` varchar(22) NOT NULL DEFAULT '' COMMENT '领主角色名',
  `laird_shape` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '领主形象',
  `laird_level` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '领主等级',
  `country` smallint(6) NOT NULL DEFAULT '0' COMMENT '领主国籍',
  `language` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '领主语言',
  `lastlogin` int(11) NOT NULL DEFAULT '0' COMMENT '领主上次登陆时间',
  `state` tinyint(3) NOT NULL DEFAULT '0' COMMENT '城池状态',
  `skin` tinyint(3) NOT NULL DEFAULT '0' COMMENT '城池皮肤',
  `vipexp` int(11) NOT NULL DEFAULT '0' COMMENT 'vip经验',
  `vipduration` int(11) NOT NULL DEFAULT '0' COMMENT 'VIP持续时间秒数',
  `clubid` int(11) NOT NULL DEFAULT '0' COMMENT '联盟编号',
  `posx` smallint(6) NOT NULL DEFAULT '0' COMMENT '位置',
  `posy` smallint(6) NOT NULL DEFAULT '0' COMMENT '位置',
  `wood` int(11) NOT NULL DEFAULT '0' COMMENT '木材',
  `wood_safe` int(11) NOT NULL DEFAULT '0' COMMENT '安全资源',
  `food` int(11) NOT NULL DEFAULT '0' COMMENT '粮食',
  `food_safe` int(11) NOT NULL DEFAULT '0' COMMENT '安全资源',
  `iron` int(11) NOT NULL DEFAULT '0' COMMENT '铁',
  `iron_safe` int(11) NOT NULL DEFAULT '0' COMMENT '安全资源',
  `mithril` int(11) NOT NULL DEFAULT '0' COMMENT '秘银',
  `mithril_safe` int(11) NOT NULL DEFAULT '0' COMMENT '安全资源',
  `body` smallint(6) NOT NULL DEFAULT '0' COMMENT '体力',
  `body_lasttime` int(11) NOT NULL DEFAULT '0' COMMENT '体力上次回复时间',
  `battlepower` int(11) NOT NULL DEFAULT '0' COMMENT '战力',
  `monster_killlevel` tinyint(3) NOT NULL DEFAULT '0' COMMENT '击杀野怪最高级别',
  `corps_num1` varbinary(80) NOT NULL DEFAULT '' COMMENT '兵数量',
  `corps_num2` varbinary(80) NOT NULL DEFAULT '',
  `corps_num3` varbinary(80) NOT NULL DEFAULT '',
  `corps_num4` varbinary(80) NOT NULL DEFAULT '',
  `corps_num5` varbinary(80) NOT NULL DEFAULT '',
  `corps_num6` varbinary(80) NOT NULL DEFAULT '',
  `corps_wound1` varbinary(80) NOT NULL DEFAULT '' COMMENT '伤兵数量',
  `corps_wound2` varbinary(80) NOT NULL DEFAULT '',
  `corps_wound3` varbinary(80) NOT NULL DEFAULT '',
  `corps_wound4` varbinary(80) NOT NULL DEFAULT '',
  `corps_wound5` varbinary(80) NOT NULL DEFAULT '',
  `corps_wound6` varbinary(80) NOT NULL DEFAULT '',
  `corps_heal1` varbinary(80) NOT NULL DEFAULT '' COMMENT '伤兵数量',
  `corps_heal2` varbinary(80) NOT NULL DEFAULT '',
  `corps_heal3` varbinary(80) NOT NULL DEFAULT '',
  `corps_heal4` varbinary(80) NOT NULL DEFAULT '',
  `corps_heal5` varbinary(80) NOT NULL DEFAULT '',
  `corps_heal6` varbinary(80) NOT NULL DEFAULT '',
  `tech_level` varbinary(256) NOT NULL DEFAULT '' COMMENT '科技等级',
  `buff_id` varbinary(64) NOT NULL DEFAULT '' COMMENT 'buff ID',
  `buff_duration` varbinary(128) NOT NULL DEFAULT '' COMMENT 'buff持续时间',
  `genius_id` varbinary(128) NOT NULL DEFAULT '' COMMENT '天赋 ID',
  `genius_level` varbinary(64) NOT NULL DEFAULT '' COMMENT '天赋等级',
  `data_record` varbinary(512) NOT NULL DEFAULT '' COMMENT '数据记录',
  `questid0` int(11) NOT NULL DEFAULT '0' COMMENT '推荐任务',
  `questvalue0` int(11) NOT NULL DEFAULT '0',
  `questid1` int(11) NOT NULL DEFAULT '0' COMMENT '普通任务',
  `questvalue1` int(11) NOT NULL DEFAULT '0',
  `questid2` int(11) NOT NULL DEFAULT '0',
  `questvalue2` int(11) NOT NULL DEFAULT '0',
  `questid3` int(11) NOT NULL DEFAULT '0',
  `questvalue3` int(11) NOT NULL DEFAULT '0',
  `questid4` int(11) NOT NULL DEFAULT '0',
  `questvalue4` int(11) NOT NULL DEFAULT '0',
  `mission_id` smallint(6) NOT NULL DEFAULT '0' COMMENT '领取到的使命ID',
  `mission_value` int(11) NOT NULL DEFAULT '0' COMMENT '当前已经完成到的使命数值',
  `mission_completenum` smallint(6) NOT NULL DEFAULT '0' COMMENT '使命完成数量',
  `honorpoint` int(11) NOT NULL DEFAULT '0' COMMENT '联盟荣誉点',
  `outunlock` tinyint(3) NOT NULL DEFAULT '0' COMMENT '城外解锁等级',
  `sflag` int(11) NOT NULL DEFAULT '0' COMMENT '标志位',
  `worker_queue1` smallint(6) NOT NULL DEFAULT '-1' COMMENT '操作队列',
  `worker_queue2` smallint(6) NOT NULL DEFAULT '-1' COMMENT '操作队列-钻石',
  `dice_time` int(11) NOT NULL DEFAULT '0' COMMENT '骰子的最后一次点击时间',
  `attack_eventid` smallint(6) NOT NULL DEFAULT '0' COMMENT 'NPC攻城事件',
  `attack_eventtownid` smallint(6) NOT NULL DEFAULT '0' COMMENT 'NPC攻城事件',
  `attack_eventwait` smallint(6) NOT NULL DEFAULT '0' COMMENT 'NPC攻城事件',
  `robot_ai` tinyint(3) NOT NULL DEFAULT '0',
  `robot_cd` int(11) NOT NULL DEFAULT '0',
  `am_totalpoint` int(11) unsigned NOT NULL DEFAULT '0',
  `am_stagepoint` int(11) unsigned NOT NULL DEFAULT '0',
  `am_stepaward` tinyint(3) NOT NULL DEFAULT '0',
  `material_makekind` varbinary(32) NOT NULL DEFAULT '',
  `material_overkind` varbinary(32) NOT NULL DEFAULT '',
  `material_maketime` int(11) NOT NULL DEFAULT '0',
  `material_queuenum` tinyint(3) NOT NULL DEFAULT '0',
  `dragoncaverndepth` int(11) NOT NULL DEFAULT '0',
  `whiteflag_clubid` int(11) NOT NULL DEFAULT '0',
  `whiteflag_endtime` int(11) NOT NULL DEFAULT '0',
  `corps_planes1` varbinary(80) NOT NULL DEFAULT '' COMMENT '位面兵数量',
  `corps_planes2` varbinary(80) NOT NULL DEFAULT '',
  `corps_planes3` varbinary(80) NOT NULL DEFAULT '',
  `corps_planes4` varbinary(80) NOT NULL DEFAULT '',
  `corps_planes5` varbinary(80) NOT NULL DEFAULT '',
  `corps_planes6` varbinary(80) NOT NULL DEFAULT '',
  `dcopencd` int(11) unsigned NOT NULL DEFAULT '0',
  `plwood` int(11) NOT NULL DEFAULT '0' COMMENT '位面收益池',
  `plfood` int(11) NOT NULL DEFAULT '0' COMMENT '位面收益池',
  `pliron` int(11) NOT NULL DEFAULT '0' COMMENT '位面收益池',
  `plmithril` int(11) NOT NULL DEFAULT '0' COMMENT '位面收益池',
  `plpower` int(11) NOT NULL DEFAULT '0' COMMENT '位面收益池',
  `pltoken` int(11) NOT NULL DEFAULT '0' COMMENT '位面收益池',
  `plres1` int(11) NOT NULL DEFAULT '0' COMMENT '位面收益池',
  `plres2` int(11) NOT NULL DEFAULT '0' COMMENT '位面收益池',
  `plriotcd` int(11) NOT NULL DEFAULT '0' COMMENT '位面起义冷却',
  `plgettime` int(11) NOT NULL DEFAULT '0' COMMENT '位面上次领取收益时间',
  `plinvadecd` int(11) NOT NULL DEFAULT '0' COMMENT '位面入侵冷却时间',
  `headid` int(11) NOT NULL DEFAULT '0' COMMENT '自定义头像ID',
  `bag_goodsid` binary(32) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0' COMMENT '轮播图礼包',
  `bag_endtime` binary(64) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `bag_count` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `cswood` int(11) NOT NULL DEFAULT '0' COMMENT '联盟仓库存储池',
  `csfood` int(11) NOT NULL DEFAULT '0' COMMENT '联盟仓库存储池',
  `csiron` int(11) NOT NULL DEFAULT '0' COMMENT '联盟仓库存储池',
  `csmithril` int(11) NOT NULL DEFAULT '0' COMMENT '联盟仓库存储池',
  `platid` tinyint(3) NOT NULL DEFAULT '0' COMMENT '平台ID',
  `official` tinyint(3) NOT NULL DEFAULT '0' COMMENT '官职',
  `hfid` tinyint(3) NOT NULL DEFAULT '0' COMMENT '头像框id',
  `cfid` tinyint(3) NOT NULL DEFAULT '0' COMMENT '聊天框id',
  `ownf` int(11) NOT NULL DEFAULT '0' COMMENT '是否拥有该框（1有0无）',
  `tflv1` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '兵种强化等级',
  `tfexp1` int(11) NOT NULL DEFAULT '0' COMMENT '兵种强化经验',
  `tflv2` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `tfexp2` int(11) NOT NULL DEFAULT '0',
  `tflv3` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `tfexp3` int(11) NOT NULL DEFAULT '0',
  `tflv4` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `tfexp4` int(11) NOT NULL DEFAULT '0',
  `tflv5` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `tfexp5` int(11) NOT NULL DEFAULT '0',
  `easter_point` int(11) NOT NULL DEFAULT '0' COMMENT '复活节砸蛋积分',
  `system` tinyint(3) NOT NULL DEFAULT '0' COMMENT '1：ios 2：android',
  PRIMARY KEY (`cityid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='城池';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `city_building`
--

DROP TABLE IF EXISTS `city_building`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city_building` (
  `cityid` int(11) NOT NULL AUTO_INCREMENT,
  `offset` smallint(6) NOT NULL DEFAULT '0' COMMENT '建筑索引,根据建造顺序确定',
  `buildingkind` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '建筑种类',
  `level` tinyint(3) NOT NULL DEFAULT '0' COMMENT '建筑等级',
  `state` tinyint(3) NOT NULL DEFAULT '0' COMMENT '当前状态',
  `begintime` int(11) NOT NULL DEFAULT '0' COMMENT '建造或升级的开始时间',
  `value1` int(11) NOT NULL DEFAULT '0' COMMENT '附加数值，根据建筑不同，作用不同',
  `value2` int(11) NOT NULL DEFAULT '0' COMMENT '附加数值，根据建筑不同，作用不同',
  `value3` int(11) NOT NULL DEFAULT '0' COMMENT '附加数值，根据建筑不同，作用不同',
  `value4` int(11) NOT NULL DEFAULT '0' COMMENT '附加数值，根据建筑不同，作用不同',
  `sflag` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '标记0是否请求过帮助',
  PRIMARY KEY (`cityid`,`offset`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='城池建筑';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `city_planes`
--

DROP TABLE IF EXISTS `city_planes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city_planes` (
  `cityid` int(11) NOT NULL DEFAULT '0',
  `planesid` tinyint(3) NOT NULL DEFAULT '0' COMMENT '位面ID',
  `state1` tinyint(3) NOT NULL DEFAULT '0' COMMENT '区域',
  `state2` tinyint(3) NOT NULL DEFAULT '0' COMMENT '区域',
  `state3` tinyint(3) NOT NULL DEFAULT '0' COMMENT '区域',
  `state4` tinyint(3) NOT NULL DEFAULT '0' COMMENT '区域',
  `state5` tinyint(3) NOT NULL DEFAULT '0' COMMENT '区域',
  `state6` tinyint(3) NOT NULL DEFAULT '0' COMMENT '区域',
  `state7` tinyint(3) NOT NULL DEFAULT '0' COMMENT '区域',
  `state8` tinyint(3) NOT NULL DEFAULT '0' COMMENT '区域',
  `diff1` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '区域',
  `diff2` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '区域',
  `diff3` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '区域',
  `diff4` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '区域',
  `diff5` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '区域',
  `diff6` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '区域',
  `diff7` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '区域',
  `diff8` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '区域',
  `serverid` smallint(6) NOT NULL DEFAULT '0' COMMENT '对手服务器ID',
  `targetid` int(11) NOT NULL DEFAULT '0' COMMENT '对手ID',
  `targetname` varchar(22) NOT NULL DEFAULT '' COMMENT '对手名',
  `targetprefix` varchar(4) NOT NULL DEFAULT '' COMMENT '对手称号',
  `targetheadid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cityid`,`planesid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='位面';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `city_planes_event`
--

DROP TABLE IF EXISTS `city_planes_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city_planes_event` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cityid` int(11) NOT NULL DEFAULT '0',
  `type` tinyint(3) NOT NULL DEFAULT '0',
  `planesid` tinyint(3) NOT NULL DEFAULT '0' COMMENT '位面ID',
  `areaid` tinyint(3) NOT NULL DEFAULT '0' COMMENT '区域ID',
  `targetname` varchar(64) NOT NULL DEFAULT '' COMMENT '内容3',
  `fightid` bigint(20) NOT NULL DEFAULT '0' COMMENT '战斗ID',
  `serverid` smallint(6) NOT NULL DEFAULT '0',
  `optime` int(11) NOT NULL DEFAULT '0' COMMENT '时间',
  PRIMARY KEY (`id`),
  KEY `cityid` (`cityid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='城池位面事件';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `city_pushkey`
--

DROP TABLE IF EXISTS `city_pushkey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city_pushkey` (
  `cityid` int(11) NOT NULL DEFAULT '0',
  `pushkey` binary(255) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  PRIMARY KEY (`cityid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `club`
--

DROP TABLE IF EXISTS `club`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `club` (
  `clubid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(22) NOT NULL DEFAULT '' COMMENT '联盟名称',
  `prefix` varchar(4) NOT NULL DEFAULT '' COMMENT '联盟简称',
  `description` varchar(128) NOT NULL DEFAULT '' COMMENT '联盟简介',
  `leadername` varchar(16) NOT NULL DEFAULT '' COMMENT '盟主名称',
  `leaderid` int(11) NOT NULL DEFAULT '0' COMMENT '领主ID',
  `flag` smallint(6) NOT NULL DEFAULT '0' COMMENT '联盟旗帜',
  `language` tinyint(3) NOT NULL DEFAULT '0' COMMENT '联盟语种',
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `battlepower` bigint(20) NOT NULL DEFAULT '0' COMMENT '战力',
  `member_maxcount` smallint(6) NOT NULL DEFAULT '0' COMMENT '联盟最高人数',
  `placename1` varchar(22) NOT NULL DEFAULT '' COMMENT '级别1称谓',
  `placename2` varchar(22) NOT NULL DEFAULT '' COMMENT '级别2称谓',
  `placename3` varchar(22) NOT NULL DEFAULT '' COMMENT '级别3称谓',
  `placename4` varchar(22) NOT NULL DEFAULT '' COMMENT '级别4称谓',
  `placename5` varchar(22) NOT NULL DEFAULT '' COMMENT '级别5称谓',
  `limit_open` tinyint(3) NOT NULL DEFAULT '0' COMMENT '限制加入开启关闭0关闭1开启',
  `limit_level` smallint(6) NOT NULL DEFAULT '0' COMMENT '限制主城等级',
  `limit_battlepower` int(11) NOT NULL DEFAULT '0' COMMENT '限制战力',
  `clubpoint` int(11) NOT NULL DEFAULT '0' COMMENT '联盟积分',
  `tecpoint` int(11) NOT NULL DEFAULT '0' COMMENT '科技点数',
  `killnum` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '总击杀人数',
  `dicetime` int(11) NOT NULL DEFAULT '0' COMMENT '色子的最后的刷新时间',
  `dicemax` tinyint(3) NOT NULL DEFAULT '0',
  `dicemax_cityid` int(11) NOT NULL DEFAULT '0',
  `activity_dragonstate` tinyint(3) NOT NULL DEFAULT '0' COMMENT '巨龙活动状态',
  `activity_dragontime` int(11) NOT NULL DEFAULT '0' COMMENT '巨龙活动下一波倒计时',
  `activity_dragonshelter` int(11) NOT NULL DEFAULT '0' COMMENT '巨龙之怒出发的庇护所',
  `activity_dragonactornum` smallint(6) NOT NULL DEFAULT '0' COMMENT '巨龙活动开启时候的人数',
  `activity_dragonpoint` bigint(20) NOT NULL DEFAULT '0' COMMENT '巨龙积分',
  `dragonskilllevel` binary(10) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0' COMMENT '龙技等级',
  `dragonskillexp` binary(40) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0' COMMENT '龙技经验',
  `technology_level` varbinary(64) NOT NULL DEFAULT '' COMMENT '联盟科技等级',
  `technology_star` varbinary(64) NOT NULL DEFAULT '' COMMENT '联盟科技星级',
  `technology_exp` varbinary(256) NOT NULL DEFAULT '' COMMENT '联盟科技经验',
  `technology_upgradekind` smallint(6) NOT NULL DEFAULT '0' COMMENT '正在升级的科技',
  `technology_begintime` int(11) NOT NULL DEFAULT '0' COMMENT '正在升级的科技开始时间',
  `questid` smallint(6) NOT NULL DEFAULT '0' COMMENT '联盟任务',
  `questvalue` int(11) NOT NULL DEFAULT '0' COMMENT '联盟任务',
  `grade` int(11) NOT NULL DEFAULT '0' COMMENT '联盟评分',
  `building_resnum` int(11) NOT NULL DEFAULT '0' COMMENT '联盟建筑资源',
  `questcomplatenum` int(11) NOT NULL DEFAULT '0' COMMENT '联盟任务完成度',
  `kingwar_point` int(11) NOT NULL DEFAULT '0' COMMENT '王城战积分',
  `kingwar_bullet` int(11) NOT NULL DEFAULT '0' COMMENT '王城战魔能塔子弹',
  `limitday` int(11) NOT NULL DEFAULT '0' COMMENT '联盟成员未上线天数限制',
  PRIMARY KEY (`clubid`),
  KEY `name` (`name`),
  KEY `prefix` (`prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `club_asklist`
--

DROP TABLE IF EXISTS `club_asklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `club_asklist` (
  `cityid` int(11) NOT NULL DEFAULT '0',
  `clubid` int(11) NOT NULL DEFAULT '0' COMMENT '申请人城池id',
  `name` varbinary(16) NOT NULL DEFAULT '' COMMENT '名称',
  `battlepower` int(11) NOT NULL DEFAULT '0' COMMENT '战力',
  `shape` char(1) NOT NULL DEFAULT '0' COMMENT '形象',
  `asktime` int(11) NOT NULL DEFAULT '0' COMMENT '申请时间',
  PRIMARY KEY (`cityid`),
  KEY `clubid` (`clubid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='联盟申请人列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `club_building_jet`
--

DROP TABLE IF EXISTS `club_building_jet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `club_building_jet` (
  `index` int(11) NOT NULL DEFAULT '0' COMMENT '索引',
  `state` tinyint(3) NOT NULL DEFAULT '0' COMMENT '状态',
  `statetime` int(11) NOT NULL DEFAULT '0' COMMENT '状态时间',
  `posx` smallint(6) NOT NULL DEFAULT '0' COMMENT '位置',
  `posy` smallint(6) NOT NULL DEFAULT '0' COMMENT '位置',
  `clubid` int(11) NOT NULL DEFAULT '0' COMMENT '所属联盟ID',
  `occupy_clubid` int(11) NOT NULL DEFAULT '0' COMMENT '占领联盟ID',
  `wear` int(11) NOT NULL DEFAULT '0' COMMENT '耐久',
  `attack_cityid` int(11) NOT NULL DEFAULT '0' COMMENT '攻击目标城池ID',
  PRIMARY KEY (`index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='联盟软泥怪';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `club_building_res`
--

DROP TABLE IF EXISTS `club_building_res`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `club_building_res` (
  `index` int(11) NOT NULL DEFAULT '0',
  `type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '资源种类',
  `state` tinyint(3) NOT NULL DEFAULT '0' COMMENT '状态',
  `statetime` int(11) NOT NULL DEFAULT '0' COMMENT '状态时间',
  `posx` smallint(6) NOT NULL DEFAULT '0' COMMENT '位置',
  `posy` smallint(6) NOT NULL DEFAULT '0' COMMENT '位置',
  `clubid` int(11) NOT NULL DEFAULT '0' COMMENT '所属联盟ID',
  PRIMARY KEY (`index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='联盟仓库';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `club_building_store`
--

DROP TABLE IF EXISTS `club_building_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `club_building_store` (
  `index` int(11) NOT NULL DEFAULT '0',
  `state` tinyint(3) NOT NULL DEFAULT '0' COMMENT '状态',
  `statetime` int(11) NOT NULL DEFAULT '0' COMMENT '状态时间',
  `posx` smallint(6) NOT NULL DEFAULT '0' COMMENT '位置',
  `posy` smallint(6) NOT NULL DEFAULT '0' COMMENT '位置',
  `clubid` int(11) NOT NULL DEFAULT '0' COMMENT '所属联盟ID',
  PRIMARY KEY (`index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='联盟仓库';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `club_building_town`
--

DROP TABLE IF EXISTS `club_building_town`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `club_building_town` (
  `index` int(11) NOT NULL DEFAULT '0' COMMENT '索引',
  `state` tinyint(3) NOT NULL DEFAULT '0' COMMENT '状态',
  `statetime` int(11) NOT NULL DEFAULT '0' COMMENT '状态时间',
  `posx` smallint(6) NOT NULL DEFAULT '0' COMMENT '位置',
  `posy` smallint(6) NOT NULL DEFAULT '0' COMMENT '位置',
  `clubid` int(11) NOT NULL DEFAULT '0' COMMENT '所属联盟ID',
  `occupy_clubid` int(11) NOT NULL DEFAULT '0' COMMENT '占领联盟ID',
  `wear` int(11) NOT NULL DEFAULT '0' COMMENT '耐久',
  `name` varchar(22) NOT NULL DEFAULT '' COMMENT '自定义名称',
  PRIMARY KEY (`index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='联盟堡垒';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `club_event`
--

DROP TABLE IF EXISTS `club_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `club_event` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `clubid` int(11) NOT NULL DEFAULT '0' COMMENT '联盟ID',
  `cityid` int(11) NOT NULL DEFAULT '0' COMMENT '城池ID',
  `type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '事件类型',
  `msg1` varchar(64) NOT NULL DEFAULT '' COMMENT '内容1',
  `msg2` varchar(64) NOT NULL DEFAULT '' COMMENT '内容2',
  `msg3` varchar(64) NOT NULL DEFAULT '' COMMENT '内容3',
  `msg4` varchar(64) NOT NULL DEFAULT '' COMMENT '内容4',
  `optime` int(11) NOT NULL DEFAULT '0' COMMENT '时间',
  PRIMARY KEY (`id`),
  KEY `clubid` (`clubid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='联盟事件';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `club_help`
--

DROP TABLE IF EXISTS `club_help`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `club_help` (
  `clubid` int(11) NOT NULL DEFAULT '0',
  `offset` tinyint(3) NOT NULL DEFAULT '0' COMMENT '索引',
  `type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '需要帮助的类型',
  `member_index` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '需要帮助成员索引',
  `building_index` smallint(6) NOT NULL DEFAULT '0' COMMENT '需要帮助的建筑',
  `times` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '已被帮助次数',
  `maxtimes` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可被帮助次数',
  PRIMARY KEY (`clubid`,`offset`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='联盟帮助';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `club_leavemsg`
--

DROP TABLE IF EXISTS `club_leavemsg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `club_leavemsg` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `clubid` int(11) NOT NULL DEFAULT '0' COMMENT '联盟ID',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '名称',
  `cityid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '城池id',
  `shape` tinyint(3) NOT NULL DEFAULT '0' COMMENT '形象',
  `flag` smallint(6) NOT NULL DEFAULT '0' COMMENT '联盟旗帜',
  `msg` varchar(512) NOT NULL DEFAULT '' COMMENT '留言内容',
  `optime` int(11) NOT NULL DEFAULT '0' COMMENT '时间',
  `sender_clubid` int(11) NOT NULL DEFAULT '0' COMMENT '留言人联盟id',
  PRIMARY KEY (`id`),
  KEY `clubid` (`clubid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='联盟留言';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `club_member`
--

DROP TABLE IF EXISTS `club_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `club_member` (
  `cityid` int(11) NOT NULL DEFAULT '0',
  `clubid` int(11) NOT NULL DEFAULT '0',
  `member_index` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '成员索引',
  `place` tinyint(3) NOT NULL DEFAULT '0' COMMENT '职位',
  `offlinetime` int(11) NOT NULL DEFAULT '0' COMMENT '下线时间',
  `help_offset` varbinary(128) NOT NULL DEFAULT '' COMMENT '帮助索引',
  `activity_dragonpoint` int(11) NOT NULL DEFAULT '0',
  `activity_dragonfailnum` tinyint(3) NOT NULL DEFAULT '0',
  `activity_dragontarget` tinyint(3) NOT NULL DEFAULT '0',
  `questpoint` int(11) NOT NULL DEFAULT '0' COMMENT '联盟任务积分',
  `questvalue` int(11) NOT NULL DEFAULT '0' COMMENT '联盟任务中提供的数值',
  `jointime` int(11) NOT NULL DEFAULT '0' COMMENT '加入时间',
  PRIMARY KEY (`cityid`),
  KEY `clubid` (`clubid`),
  KEY `member_index` (`member_index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `club_shop`
--

DROP TABLE IF EXISTS `club_shop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `club_shop` (
  `clubid` int(11) NOT NULL DEFAULT '0',
  `itemkind` int(11) NOT NULL DEFAULT '0',
  `num` smallint(6) NOT NULL DEFAULT '0' COMMENT '价格',
  PRIMARY KEY (`clubid`,`itemkind`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `club_shoplog`
--

DROP TABLE IF EXISTS `club_shoplog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `club_shoplog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clubid` int(11) NOT NULL DEFAULT '0',
  `type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '1 为商城 2 为物品清单',
  `actorid` int(11) NOT NULL DEFAULT '0',
  `actor_name` varchar(22) NOT NULL DEFAULT '',
  `itemkind` int(11) NOT NULL DEFAULT '0',
  `num` tinyint(3) NOT NULL DEFAULT '0',
  `optime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_clubid` (`clubid`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `command_data`
--

DROP TABLE IF EXISTS `command_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `command_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cond` int(11) NOT NULL DEFAULT '0',
  `cmd` int(11) NOT NULL DEFAULT '0' COMMENT 'GM指令',
  `value1` int(11) NOT NULL DEFAULT '0',
  `value2` int(11) NOT NULL DEFAULT '0',
  `value3` int(11) NOT NULL DEFAULT '0',
  `value4` int(11) NOT NULL DEFAULT '0',
  `strvalue` varchar(1024) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `timestr` varbinary(128) NOT NULL DEFAULT '',
  `addtime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fight_rec`
--

DROP TABLE IF EXISTS `fight_rec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fight_rec` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '战斗类型',
  `attack` varchar(4096) NOT NULL DEFAULT '',
  `defense` varchar(4096) NOT NULL DEFAULT '',
  `optime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gift`
--

DROP TABLE IF EXISTS `gift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gift` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `actorid` int(11) NOT NULL DEFAULT '0' COMMENT '角色id',
  `kind1` int(11) NOT NULL DEFAULT '0' COMMENT '类型',
  `num1` int(11) NOT NULL DEFAULT '0' COMMENT '值',
  `color1` tinyint(3) NOT NULL DEFAULT '0',
  `kind2` int(11) NOT NULL DEFAULT '0' COMMENT '类型',
  `num2` int(11) NOT NULL DEFAULT '0' COMMENT '值',
  `color2` tinyint(3) NOT NULL DEFAULT '0',
  `kind3` int(11) NOT NULL DEFAULT '0' COMMENT '类型',
  `num3` int(11) NOT NULL DEFAULT '0' COMMENT '值',
  `color3` tinyint(3) NOT NULL DEFAULT '0',
  `kind4` int(11) NOT NULL DEFAULT '0' COMMENT '类型',
  `num4` int(11) NOT NULL DEFAULT '0' COMMENT '值',
  `color4` tinyint(3) NOT NULL DEFAULT '0',
  `path` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `actorid` (`actorid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gift_uid`
--

DROP TABLE IF EXISTS `gift_uid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gift_uid` (
  `uid` varchar(64) NOT NULL DEFAULT '',
  `kind1` int(11) NOT NULL DEFAULT '0',
  `num1` int(11) NOT NULL DEFAULT '0',
  `color1` tinyint(3) NOT NULL DEFAULT '0',
  `kind2` int(11) NOT NULL DEFAULT '0' COMMENT '类型',
  `num2` int(11) NOT NULL DEFAULT '0' COMMENT '值',
  `color2` tinyint(3) NOT NULL DEFAULT '0',
  `kind3` int(11) NOT NULL DEFAULT '0' COMMENT '类型',
  `num3` int(11) NOT NULL DEFAULT '0' COMMENT '值',
  `color3` tinyint(3) NOT NULL DEFAULT '0',
  `kind4` int(11) NOT NULL DEFAULT '0' COMMENT '类型',
  `num4` int(11) NOT NULL DEFAULT '0' COMMENT '值',
  `color4` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='根据UID进行奖励';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `king_city`
--

DROP TABLE IF EXISTS `king_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `king_city` (
  `id` int(11) NOT NULL DEFAULT '0' COMMENT '索引',
  `state` tinyint(3) NOT NULL DEFAULT '0' COMMENT '状态',
  `statetime` int(11) NOT NULL DEFAULT '0' COMMENT '状态时间',
  `serverid` smallint(6) NOT NULL DEFAULT '0' COMMENT '服务器ID',
  `clubid` int(11) NOT NULL DEFAULT '0' COMMENT '所属联盟ID',
  `occupy_troopcount_max` int(11) NOT NULL DEFAULT '0' COMMENT '驻防最大人数',
  `occupy_troopcount` int(11) NOT NULL DEFAULT '0' COMMENT '驻防当前人数',
  `king_cityid` int(11) NOT NULL DEFAULT '0' COMMENT '国王ID',
  `server_name` varchar(22) NOT NULL DEFAULT '' COMMENT '服务器名',
  `totalpoint` int(11) NOT NULL DEFAULT '0' COMMENT '所有联盟总积分',
  `brush_turns` smallint(6) NOT NULL DEFAULT '0' COMMENT '刷怪次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='王城';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `king_tower`
--

DROP TABLE IF EXISTS `king_tower`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `king_tower` (
  `index` int(11) NOT NULL DEFAULT '0' COMMENT '索引',
  `state` tinyint(3) NOT NULL DEFAULT '0' COMMENT '状态',
  `statetime` int(11) NOT NULL DEFAULT '0' COMMENT '状态时间',
  `clubid` int(11) NOT NULL DEFAULT '0' COMMENT '所属联盟ID',
  `occupy_troopcount_max` int(11) NOT NULL DEFAULT '0' COMMENT '驻防最大人数',
  `occupy_troopcount` int(11) NOT NULL DEFAULT '0' COMMENT '驻防当前人数',
  `attack_type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '攻击类型',
  `attack_cd` int(11) NOT NULL DEFAULT '0' COMMENT '攻击倒计时',
  PRIMARY KEY (`index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='魔能塔';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kingwar_giftuse`
--

DROP TABLE IF EXISTS `kingwar_giftuse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kingwar_giftuse` (
  `index` int(11) NOT NULL DEFAULT '0',
  `cityid` int(11) NOT NULL DEFAULT '0',
  `giftid` tinyint(3) NOT NULL DEFAULT '0',
  `name` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kingwar_history`
--

DROP TABLE IF EXISTS `kingwar_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kingwar_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '国王名',
  `signature` varchar(255) NOT NULL DEFAULT '' COMMENT '任内签名',
  `cityid` int(11) NOT NULL DEFAULT '0' COMMENT '城池ID',
  `serverid` smallint(6) NOT NULL DEFAULT '0' COMMENT '服务器',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='王城战历史';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mail`
--

DROP TABLE IF EXISTS `mail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mail` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `from_actorid` int(11) NOT NULL DEFAULT '0' COMMENT '发送人id',
  `from_name` varchar(32) NOT NULL DEFAULT '' COMMENT '发送人名称',
  `to_actorid` int(11) NOT NULL DEFAULT '0' COMMENT '收件人id',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '邮件类型',
  `title` varchar(64) NOT NULL DEFAULT '' COMMENT '标题',
  `content` varchar(1024) NOT NULL DEFAULT '' COMMENT '内容',
  `attach` varchar(256) NOT NULL DEFAULT '' COMMENT '附件',
  `attach_isget` tinyint(3) NOT NULL DEFAULT '0' COMMENT '附件是否已经领取',
  `recvtime` int(11) NOT NULL DEFAULT '0' COMMENT '收件时间',
  `deltime` int(11) NOT NULL DEFAULT '0' COMMENT '删除时间',
  `read` tinyint(3) NOT NULL DEFAULT '0' COMMENT '0未读，1已读',
  `fightid` bigint(20) NOT NULL DEFAULT '0' COMMENT '战斗录像',
  PRIMARY KEY (`id`),
  KEY `to_actorid` (`to_actorid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='邮件';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mail_fightdetail`
--

DROP TABLE IF EXISTS `mail_fightdetail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mail_fightdetail` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `attack_troops` varchar(8192) NOT NULL DEFAULT '' COMMENT '部队详情',
  `defense_troops` varchar(8192) NOT NULL DEFAULT '' COMMENT '部队详情',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mail_text`
--

DROP TABLE IF EXISTS `mail_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mail_text` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(4096) NOT NULL DEFAULT '',
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '收件时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `map_activity`
--

DROP TABLE IF EXISTS `map_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `map_activity` (
  `index` int(11) NOT NULL DEFAULT '0',
  `id` smallint(6) NOT NULL DEFAULT '0' COMMENT '怪物ID',
  `action` tinyint(3) NOT NULL DEFAULT '0' COMMENT '状态',
  `actiontime` int(11) NOT NULL DEFAULT '0' COMMENT '状态时间戳',
  `posx` smallint(6) NOT NULL DEFAULT '0' COMMENT '位置',
  `posy` smallint(6) NOT NULL DEFAULT '0' COMMENT '位置',
  `value1` int(11) NOT NULL DEFAULT '0',
  `value2` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='野外活动怪';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `map_army`
--

DROP TABLE IF EXISTS `map_army`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `map_army` (
  `index` int(11) NOT NULL DEFAULT '0',
  `from_type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '出发',
  `from_id` int(11) NOT NULL DEFAULT '0' COMMENT '出发',
  `from_posx` smallint(6) NOT NULL DEFAULT '0' COMMENT '出发位置',
  `from_posy` smallint(6) NOT NULL DEFAULT '0' COMMENT '出发位置',
  `target_type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '目标',
  `target_id` int(11) NOT NULL DEFAULT '0' COMMENT '目标',
  `target_posx` smallint(6) NOT NULL DEFAULT '0' COMMENT '目标位置',
  `target_posy` smallint(6) NOT NULL DEFAULT '0' COMMENT '目标位置',
  `target_mark` int(11) NOT NULL DEFAULT '0' COMMENT '记号',
  `state` tinyint(3) NOT NULL DEFAULT '0' COMMENT '部队的状态',
  `statetime` int(11) NOT NULL DEFAULT '0' COMMENT '状态时间戳',
  `stateduration` int(11) NOT NULL DEFAULT '0' COMMENT '状态持续时间',
  `action` tinyint(3) NOT NULL DEFAULT '0' COMMENT '行为',
  `appdata` int(11) NOT NULL DEFAULT '0' COMMENT '附加数据',
  `posx` smallint(6) NOT NULL DEFAULT '0' COMMENT '当前位置',
  `posy` smallint(6) NOT NULL DEFAULT '0' COMMENT '当前位置',
  `carry_wood` float(11,3) NOT NULL DEFAULT '0.000' COMMENT '采集或掠夺的木材',
  `carry_food` float(11,3) NOT NULL DEFAULT '0.000' COMMENT '采集或掠夺的粮食',
  `carry_iron` float(11,3) NOT NULL DEFAULT '0.000' COMMENT '采集或掠夺的铁矿',
  `carry_mithril` float(11,3) NOT NULL DEFAULT '0.000' COMMENT '采集或掠夺的秘银',
  `carry_token` float(11,3) NOT NULL DEFAULT '0.000' COMMENT '采集或掠夺的钻石',
  `troop_corps` binary(20) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0' COMMENT '作战单位',
  `troop_level` binary(10) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0' COMMENT '作战单位等级',
  `troop_number` binary(40) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0' COMMENT '作战单位数量',
  `troop_woundnumber` binary(40) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0' COMMENT '受伤单位数量',
  `call_ghostlevel` tinyint(3) NOT NULL DEFAULT '0' COMMENT '召唤幽魂等级',
  `call_ghostnum` int(11) NOT NULL DEFAULT '0' COMMENT '召唤幽魂数量',
  `mailid` bigint(20) NOT NULL DEFAULT '0' COMMENT '关联邮件id',
  `battlepower` int(11) NOT NULL DEFAULT '0' COMMENT '部队战力',
  `v1` int(11) NOT NULL DEFAULT '0' COMMENT '额外值',
  `v2` int(11) NOT NULL DEFAULT '0' COMMENT '额外值',
  `v3` int(11) NOT NULL DEFAULT '0' COMMENT '额外值',
  `v4` int(11) NOT NULL DEFAULT '0' COMMENT '额外值',
  `ck1` int(11) NOT NULL DEFAULT '0' COMMENT '携带道具',
  `cn1` int(11) NOT NULL DEFAULT '0',
  `ck2` int(11) NOT NULL DEFAULT '0' COMMENT '携带道具',
  `cn2` int(11) NOT NULL DEFAULT '0',
  `ck3` int(11) NOT NULL DEFAULT '0' COMMENT '携带道具',
  `cn3` int(11) NOT NULL DEFAULT '0',
  `ck4` int(11) NOT NULL DEFAULT '0' COMMENT '携带道具',
  `cn4` int(11) NOT NULL DEFAULT '0',
  `ck5` int(11) NOT NULL DEFAULT '0' COMMENT '携带道具',
  `cn5` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='出征部队';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `map_monster`
--

DROP TABLE IF EXISTS `map_monster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `map_monster` (
  `index` int(11) NOT NULL DEFAULT '0',
  `monsterid` smallint(6) NOT NULL DEFAULT '0' COMMENT '怪物ID',
  `action` tinyint(3) NOT NULL DEFAULT '0' COMMENT '状态',
  `actiontime` int(11) NOT NULL DEFAULT '0' COMMENT '状态时间戳',
  `posx` smallint(6) NOT NULL DEFAULT '0' COMMENT '位置',
  `posy` smallint(6) NOT NULL DEFAULT '0' COMMENT '位置',
  `deltime` int(11) NOT NULL DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='野外怪物';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `map_res`
--

DROP TABLE IF EXISTS `map_res`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `map_res` (
  `index` int(11) NOT NULL DEFAULT '0',
  `resid` smallint(6) NOT NULL DEFAULT '0' COMMENT '资源编号',
  `fvalue` float(11,3) NOT NULL DEFAULT '0.000' COMMENT '资源数量',
  `posx` smallint(6) NOT NULL DEFAULT '0' COMMENT '位置',
  `posy` smallint(6) NOT NULL DEFAULT '0' COMMENT '位置',
  `brushtime` int(11) NOT NULL DEFAULT '0' COMMENT '刷新时间',
  PRIMARY KEY (`index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='野外资源点';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `map_shelter`
--

DROP TABLE IF EXISTS `map_shelter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `map_shelter` (
  `index` int(11) NOT NULL DEFAULT '0',
  `posx` smallint(6) NOT NULL DEFAULT '0' COMMENT '位置',
  `posy` smallint(6) NOT NULL DEFAULT '0' COMMENT '位置',
  `deltime` int(11) NOT NULL DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='庇护所';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `map_town`
--

DROP TABLE IF EXISTS `map_town`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `map_town` (
  `townid` int(11) NOT NULL DEFAULT '0',
  `state` tinyint(3) NOT NULL DEFAULT '0' COMMENT '状态',
  `statetime` int(11) NOT NULL DEFAULT '0' COMMENT '状态时间',
  `hp` int(11) NOT NULL DEFAULT '0' COMMENT '城防值',
  `attackcd` int(11) NOT NULL DEFAULT '0' COMMENT '攻击CD',
  `clubid` int(11) NOT NULL DEFAULT '0' COMMENT '占领的联盟',
  `occupy_troopcount_max` int(11) NOT NULL DEFAULT '0' COMMENT '驻扎最大数量',
  PRIMARY KEY (`townid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='野外城镇';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `map_town_event`
--

DROP TABLE IF EXISTS `map_town_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `map_town_event` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `townid` smallint(5) NOT NULL DEFAULT '0',
  `type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '1攻击 2防御 3状态改变',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '名字',
  `prefix` varchar(32) NOT NULL DEFAULT '' COMMENT '称号',
  `clubname` varchar(32) NOT NULL DEFAULT '',
  `result` tinyint(3) NOT NULL DEFAULT '0' COMMENT '结果1胜利2失败',
  `value1` int(11) NOT NULL DEFAULT '0',
  `value2` int(11) NOT NULL DEFAULT '0',
  `optime` int(11) NOT NULL DEFAULT '0' COMMENT '时间',
  PRIMARY KEY (`id`),
  KEY `townid` (`townid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pay_offline`
--

DROP TABLE IF EXISTS `pay_offline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_offline` (
  `actorid` int(11) NOT NULL DEFAULT '0',
  `orderid` char(32) NOT NULL DEFAULT '',
  `goodsid` smallint(6) NOT NULL DEFAULT '0',
  `optime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`actorid`,`orderid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='离线的充值数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pay_order`
--

DROP TABLE IF EXISTS `pay_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_order` (
  `orderid` char(32) NOT NULL DEFAULT '',
  `userid` bigint(20) NOT NULL DEFAULT '0' COMMENT '游戏用户ID',
  `actorid` int(11) NOT NULL DEFAULT '0' COMMENT '游戏角色ID',
  `actorlevel` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '角色等级',
  `citylevel` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '主城等级',
  `productid` smallint(6) NOT NULL DEFAULT '0' COMMENT '平台产品ID',
  `goodsid` smallint(6) NOT NULL DEFAULT '0' COMMENT '游戏商品ID',
  `awardgroup` int(11) NOT NULL DEFAULT '0' COMMENT '奖励组',
  `ip` char(15) NOT NULL DEFAULT '0.0.0.0' COMMENT '地址',
  `status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '支付状态  0待支付 1支付成功',
  `optime` int(11) NOT NULL DEFAULT '0' COMMENT '生成时间',
  PRIMARY KEY (`orderid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `robot_name`
--

DROP TABLE IF EXISTS `robot_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `robot_name` (
  `id` int(11) NOT NULL,
  `country` smallint(6) NOT NULL DEFAULT '0',
  `name` varchar(22) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `country` (`country`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `troop_resumed`
--

DROP TABLE IF EXISTS `troop_resumed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `troop_resumed` (
  `actorid` int(11) NOT NULL DEFAULT '0',
  `crops` int(11) NOT NULL DEFAULT '0',
  `level` int(11) NOT NULL DEFAULT '0',
  `num` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`actorid`,`crops`,`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `world_data`
--

DROP TABLE IF EXISTS `world_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `world_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` int(11) NOT NULL DEFAULT '0',
  `strvalue` varbinary(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='世界数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `world_talkcache`
--

DROP TABLE IF EXISTS `world_talkcache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `world_talkcache` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(3) NOT NULL DEFAULT '0',
  `cityid` int(11) NOT NULL DEFAULT '0',
  `name` varchar(22) NOT NULL DEFAULT '',
  `msg` varchar(255) NOT NULL DEFAULT '',
  `shape` tinyint(3) NOT NULL DEFAULT '0',
  `sendtime` int(11) NOT NULL DEFAULT '0',
  `clubid` int(11) NOT NULL DEFAULT '0',
  `prefix` varchar(4) NOT NULL DEFAULT '',
  `viplevel` tinyint(3) NOT NULL DEFAULT '0',
  `headid` int(11) NOT NULL DEFAULT '0' COMMENT '自定义头像',
  `actorid` int(11) NOT NULL DEFAULT '0',
  `flag` tinyint(3) NOT NULL DEFAULT '0',
  `hfid` tinyint(3) NOT NULL DEFAULT '0' COMMENT '当前使用的头像框',
  `cfid` tinyint(3) NOT NULL DEFAULT '0' COMMENT '当前使用的聊天框',
  `serverid` smallint(6) NOT NULL DEFAULT '0' COMMENT '服务器ID',
  PRIMARY KEY (`id`),
  KEY `clubid` (`clubid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-04-19 22:46:54
