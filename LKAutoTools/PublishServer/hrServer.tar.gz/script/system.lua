
local totle_minute;
function IN_GetCondSql( cond, sql )
	
end

-- ϵͳ����ʱִ��
function IN_Script_Init()
	math.randomseed(os.time())
end

-- ϵͳÿ����ִ��һ��
function IN_Script_Timer()
	
end

-- ϵͳÿСʱִ��һ��
function IN_Script_Hour()

end

-- ����ִ��
function IN_OnClockProcess( hour )
	if hour == 3 then

	end
end

-- ϵͳʱ���ַ���
function IN_TimeString( timestamp )
	return os.date("%Y-%m-%d %X", timestamp), 0;
end

-- ϵͳGMָ��
function IN_Script_Command( v1, v2, v3, v4, msg, PlayerIdx )
	local temp = os.date("*t", os.time());
	
	if v1 == 1 then
		
	end
	return 0;
end

function IN_Script_Exec( id, value1, value2 )
	
end

